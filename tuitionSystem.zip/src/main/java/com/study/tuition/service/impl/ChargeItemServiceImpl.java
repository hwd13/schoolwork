package com.study.tuition.service.impl;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.ChargeItem;
import com.study.tuition.domain.ChargeItemExample;
import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.mapper.ChargeItemMapper;
import com.study.tuition.service.ChargeItemService;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.MajorService;

@Service
public class ChargeItemServiceImpl implements ChargeItemService{

    @Autowired
    private ChargeItemMapper chargeItemMapper;
    @Autowired
    private MajorService majorService;
    @Autowired
    private ClassService classService;
    
    @Override
    public ChargeItem getById(Long id) {
        ChargeItem chargeItem = chargeItemMapper.selectByPrimaryKey(id);
        return this.setMajorName(chargeItem);
    }

    @Override
    public void insert(ChargeItem chargeItem) {
        chargeItem.setSchoolYear(this.getSchoolYear());
        chargeItemMapper.insertSelective(chargeItem);
    }

    @Override
    public void update(ChargeItem chargeItem) {
        chargeItemMapper.updateByPrimaryKeySelective(chargeItem);
    }

    @Override
    public List<ChargeItem> getChargeItemList(int page, int row) {
        List<ChargeItem> list = chargeItemMapper.selectByPage((page -1) * row, row);
        return this.setMajorNameList(list);
    }
    
    @Override
    public PaymentInfo createPaymentInfo(StudentInfo studentInfo) {
        PaymentInfo paymentInfo = new PaymentInfo();
        paymentInfo.setStudentId(studentInfo.getId());
        
        int tuition = this.getTuition(studentInfo);
        paymentInfo.setTuition(tuition);
        paymentInfo.setArrear(tuition);
        
        paymentInfo.setHirePurchaseCount(1);
        paymentInfo.setSchoolYear(this.getSchoolYear());
        paymentInfo.setPayStatus(false);
        return paymentInfo;
    }

    @Override
    public List<ChargeItem> getChargeItemByStudent(StudentInfo studentInfo) {
        List<ChargeItem> chargeItemList = chargeItemMapper.selectByExample(new ChargeItemExample());
        Iterator<ChargeItem> iterator = chargeItemList.iterator();
        ChargeItem chargeItem = null;
        MajorInfo major = null;
        boolean isChargeMajor = false;
        boolean isChargeGrade = false;
        boolean isChargeStudentCategory = false;
        boolean isChargeSchoolYear = false;
        while (iterator.hasNext()) {
            chargeItem = iterator.next();
            
            major = this.getMajorByStudent(studentInfo);
            isChargeMajor = chargeItem.getMajorId().equals(major.getId());
            isChargeGrade = chargeItem.getEnrollmentYear().equals(this.getEnrollmentDateByStudentId(studentInfo.getId()));
            isChargeStudentCategory = chargeItem.getStudentCategory().equals(studentInfo.getCategory());
            isChargeSchoolYear = chargeItem.getSchoolYear().equals(this.getSchoolYear());
            
            if (!isChargeMajor || !isChargeGrade || !isChargeStudentCategory || !isChargeSchoolYear) {
                iterator.remove();
            }
        }
        return chargeItemList;
    }
    
    /**
     * 设置收费项目的专业名称
     * 
     * @param chargeItem
     * @return
     */
    private ChargeItem setMajorName(ChargeItem chargeItem) {
        MajorInfo majorInfo = majorService.getById(chargeItem.getMajorId());
        chargeItem.setMajorName(majorInfo.getName());
        return chargeItem;
    }
    
    /**
     * 设置list中每个收费项目的专业名称
     * 
     * @param list
     * @return
     */
    private List<ChargeItem> setMajorNameList(List<ChargeItem> list) {
        MajorInfo majorInfo = null;
        for (ChargeItem chargeItem : list) {
            majorInfo = majorService.getById(chargeItem.getMajorId());
            chargeItem.setMajorName(majorInfo.getName());
        }
        return list;
    }
    
    /**
     * 根据学生获取当前学年的学费
     * 
     * @param studentInfo
     * @return
     */
    private int getTuition(StudentInfo studentInfo) {
        int tuition = 0; 
        for (ChargeItem chargeItem : this.getChargeItemByStudent(studentInfo)) {
            tuition += chargeItem.getMoney();
        }
        return tuition;
    }

    /**
     * 根据学号前四位获取入学年份
     * 
     * @param studentId
     * @return
     */
    private Integer getEnrollmentDateByStudentId(Long studentId) {
        String valueOf = String.valueOf(studentId);
        String enrollmentDateStr = valueOf.substring(0, 4);
        return Integer.parseInt(enrollmentDateStr);
    }

    /**
     * 根据学号获取专业
     * 
     * @param studentId
     * @return
     */
    private MajorInfo getMajorByStudent(StudentInfo studentInfo) {
        ClassInfo classInfo = classService.getById(studentInfo.getClassId());
        return majorService.getById(classInfo.getMajorId());
    }

    /**
     * 获取学年(即从当年9月1日到次年的8月31日)
     * 
     * @return
     */
    private Integer getSchoolYear() {
        LocalDate now = LocalDate.now();
        int monthValue = now.getMonthValue();
        int year = now.getYear();
        return monthValue >= 9 ? year : year - 1;
    }

    @Override
    public int getTotal() {
        return chargeItemMapper.countByExample(new ChargeItemExample());
    }
}
