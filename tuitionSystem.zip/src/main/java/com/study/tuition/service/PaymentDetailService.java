package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.PaymentDetail;
import com.study.tuition.domain.PaymentInfo;

public interface PaymentDetailService {
    /**
     * 通过学号来返回学生缴费详情
     * @param studentId
     * @return
     */
    List<PaymentDetail> getListByStudentId(Long studentId);
    
    /**
     * 根据缴费信息、缴费金额、支付方式创建缴费详情
     * 
     * @param paymentInfo
     * @return
     */
    PaymentDetail createPaymentDetail(PaymentInfo paymentInfo);
    
    /**
     * 添加缴费详情
     * @param paymentDetail
     */
    void insert(PaymentDetail paymentDetail);
    
    /**
     * 修改缴费详情
     * @param paymentDetail
     */
    void update(PaymentDetail paymentDetail);
    
}
