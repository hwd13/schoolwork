package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.ChargeItem;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.StudentInfo;

public interface ChargeItemService {
    /**
     * 通过收费项目id返回收费项目信息
     * @param id
     * @return
     */
    ChargeItem getById(Long id);
    
    /**
     * 获取所有收费项目的数目
     * 
     * @return
     */
    int getTotal();
    
    /**
     * 根据页和行来获取数据 
     * @param page
     * @param row
     * @return
     */
    List<ChargeItem> getChargeItemList(int page, int row);
    
    /**
     * 添加收费项目
     * @param chargeItem
     */
    void insert(ChargeItem chargeItem);
    
    /**
     * 更新收费项目
     * @param chargeItem
     */
    void update(ChargeItem chargeItem);
    
    /**
     * 根据学生创建一个缴费信息
     * 
     * @param studentInfo
     * @return
     */
    PaymentInfo createPaymentInfo(StudentInfo studentInfo);

    /**
     * 根据学生获取收费项目
     * 
     * @param studentInfo
     * @return
     */
    List<ChargeItem> getChargeItemByStudent(StudentInfo studentInfo);
}
