package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.MajorInfo;

public interface MajorService {
    /**
     * 通过专业Id返回专业信息
     * @param majorId
     * @return
     */
    MajorInfo getById(Long majorId);
    
    /**
     * 获取专业数量
     * @return
     */
    int getTotal();
    
    /**
     * 根据页和行返回专业信息
     * 
     * @param page
     * @param row
     * @return
     */
    List<MajorInfo> getMajorList(int page , int row);
    
    /**
     * 通过专业名称和入学年份返回专业
     * 
     * @param name
     * @return
     */
    MajorInfo getMajorByNameAndYear(String name, Integer enrollmentYear);
    
    /**
     * 根据专业名称来获取专业信息
     * 
     * @param name
     * @return
     */
    List<MajorInfo> getListByName(String name);
    
    /**
     * 通过系部名称返回该系部的专业
     * 
     * @param departmentName
     * @return
     */
    List<MajorInfo> getListByDepartmentName(String departmentName);
    
    /**
     * 添加专业
     * @param majorInfo
     */
    void insert(MajorInfo majorInfo);
    
    /**
     * 修改专业信息
     * @param majorInfo
     */
    void update(MajorInfo majorInfo);
    
    
}
