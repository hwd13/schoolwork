package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.MenuInfo;

public interface MenuInfoService {
    /**
     * 通过角色Id返回该角色的菜单信息 (null-所有菜单)
     * @param roleId
     * @return
     */
    List<MenuInfo> getMenuListByRoleId(Long roleId);
    
    /**
     * 返回所有菜单
     * 
     * @return
     */
    List<MenuInfo> getMenuList();
    
    /**
     * 通过menuIdList返回菜单或按钮
     * @param list
     * @return
     */
    List<MenuInfo> getByIdList(List<Long> list);
    
    /**
     * 通过角色id返回该角色的所有按钮
     * 
     * @param roleId
     * @return
     */
    List<MenuInfo> getButtonByRoleId(Long roleId);
    
    /**
     * 返回所有按钮
     * 
     * @return
     */
    List<MenuInfo> getButtonList();
    
    /**
     * 设置默认选中的菜单
     * 
     * @param roleId
     * @return
     */
    List<MenuInfo> setCheckedMenuList(Long roleId);
}
