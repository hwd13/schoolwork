package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.UserInfo;

public interface UserService {
    
    /**
     * 检查登录
     * @param userName
     * @param password
     * @return
     */
    boolean checkLogin(String userName, String password);
    
    /**
     * 检查密码
     * @param userInfo
     * @param password
     * @return
     */
    boolean checkPassowrd(UserInfo userInfo, String password);
    
    /**
     * 通过用户ID返回用户信息
     * @param userId
     * @return
     */
    UserInfo getById(Long userId);
    
    /**
     * 通过用户名获取用户信息
     * @param userName
     * @return
     */
    UserInfo getByUserName(String userName);
    
    /**
     * 根据姓名获取用户信息
     * @param name
     * @return
     */
    List<UserInfo> getByName(String name);
    
    /**
     * 返回是学生的用户
     * 
     * @return
     */
    List<UserInfo> getStudentUserList();
    
    /**
     * 返回是职工的用户
     * 
     * @return
     */
    List<UserInfo> getEmployeeUserList();
    
    /**
     * 根据页和行返回用户信息
     * @param page
     * @param row
     * @return
     */
    List<UserInfo> getUserList(int page, int row);
    
    /**
     * 获取用户数量
     * 
     * @return
     */
    int getTotal();
    
    /**
     * 添加用户
     * @param userInfo
     * @return 返回新增的用户ID
     */
    Long insert(UserInfo userInfo);
    
    /**
     * 批量添加用户并且返回用户信息
     * 
     * @param list
     * @return
     */
    List<UserInfo> insertBatch(List<UserInfo> list);
    
    /**
     * 修改用户
     * @param userInfo
     */
    void update(UserInfo userInfo);
    
}
