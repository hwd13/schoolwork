package com.study.tuition.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.EmployeeInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.domain.StudentInfoExample;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.mapper.StudentInfoMapper;
import com.study.tuition.service.ChargeItemService;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.EmployeeService;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.PaymentInfoService;
import com.study.tuition.service.StudentService;
import com.study.tuition.service.UserService;
import com.study.tuition.util.ExcelUtil;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentInfoMapper studentInfoMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private ClassService classService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private MajorService majorService;
    @Autowired
    private ChargeItemService chargeItemService;
    @Autowired
    private PaymentInfoService paymentInfoService;

    @Override
    public void insert(StudentInfo studentInfo) {
        UserInfo userInfo = studentInfo.getUserInfo();

        StudentInfo student = this.insertStudent(studentInfo);
        userInfo.setUserName(student.getId().toString());
        userInfo.setPassword(student.getId().toString());
        userInfo.setRoleId(4L);
        Long userId = userService.insert(userInfo);

        student.setUserId(userId);
        this.update(student);

        PaymentInfo paymentInfo = chargeItemService.createPaymentInfo(studentInfo);
        paymentInfoService.insert(paymentInfo);
    }

    @Override
    public void update(StudentInfo studentInfo) {
        studentInfoMapper.updateByPrimaryKeySelective(studentInfo);
    }

    @Override
    public StudentInfo getById(Long studentId) {
        StudentInfo studentInfo = studentInfoMapper.selectByPrimaryKey(studentId);
        return this.setClassInfo(this.setUserInfo(studentInfo));
    }

    @Override
    public List<StudentInfo> getListByName(String name) {
        List<UserInfo> list = userService.getByName(name);
        List<StudentInfo> studentList = new ArrayList<>();
        StudentInfoExample example = new StudentInfoExample();
        for (UserInfo user : list) {
            example.or().andUserIdEqualTo(user.getId());
            List<StudentInfo> selectList = studentInfoMapper.selectByExample(example);
            studentList.addAll(selectList);
            example.clear();
        }
        return this.setClassInfoList(this.setUserInfoList(studentList));
    }

    @Override
    public List<StudentInfo> getListByClassId(Long classId) {
        StudentInfoExample example = new StudentInfoExample();
        example.or().andClassIdEqualTo(classId);
        List<StudentInfo> list = studentInfoMapper.selectByExample(example);
        return this.setClassInfoList(this.setUserInfoList(list));
    }

    @Override
    public List<StudentInfo> getListByMajorId(Long majorId) {
        List<ClassInfo> classList = classService.getListByMajorId(majorId);
        List<StudentInfo> studentList = null;
        if (classList.isEmpty()) {
            return null;
        } else {
            studentList = new ArrayList<>();
        }
        List<StudentInfo> oneClassStudentList = null;
        for (ClassInfo classInfo : classList) {
            oneClassStudentList = this.getListByClassId(classInfo.getId());
            studentList.addAll(oneClassStudentList);
        }

        return this.setClassInfoList(this.setUserInfoList(studentList));
    }

    @Override
    public List<StudentInfo> getListByEmployeeId(Long employeeId) {
        EmployeeInfo employeeInfo = employeeService.getById(employeeId);
        UserInfo userInfo = userService.getById(employeeInfo.getUserId());
        List<StudentInfo> studentList = null;
        // 3 为辅导员
        if (userInfo.getRoleId() == 3) {
            studentList = new ArrayList<>();
            List<ClassInfo> classList = classService.getListByEmployeeId(employeeInfo.getId());
            List<StudentInfo> oneClassStudentList = null;
            for (ClassInfo classInfo : classList) {
                oneClassStudentList = this.getListByClassId(classInfo.getId());
                studentList.addAll(oneClassStudentList);
            }
        }
        return this.setClassInfoList(this.setUserInfoList(studentList));
    }

    @Override
    public List<StudentInfo> getListByDepartmentName(String departmentName) {
        List<MajorInfo> majorList = majorService.getListByDepartmentName(departmentName);
        List<StudentInfo> studentList = new ArrayList<>();
        if (majorList.isEmpty()) {
            return studentList;
        }
        List<StudentInfo> oneMajorStudentList = null;
        for (MajorInfo major : majorList) {
            oneMajorStudentList = this.getListByMajorId(major.getId());
            studentList.addAll(oneMajorStudentList);
        }
        return this.setClassInfoList(this.setUserInfoList(studentList));
    }

    /**
     * 设置学生的用户信息
     * 
     * @param student
     * @return
     */
    private StudentInfo setUserInfo(StudentInfo student) {
        if (student == null) {
            return null;
        }
        UserInfo userInfo = userService.getById(student.getUserId());
        student.setUserInfo(userInfo);
        return student;
    }

    /**
     * 设置list中学生的用户信息
     * 
     * @param list
     * @return
     */
    private List<StudentInfo> setUserInfoList(List<StudentInfo> list) {
        for (StudentInfo studentInfo : list) {
            studentInfo = this.setUserInfo(studentInfo);
        }
        return list;
    }

    /**
     * 设置学生的班级信息
     * 
     * @param student
     * @return
     */
    private StudentInfo setClassInfo(StudentInfo student) {
        if (student == null) {
            return null;
        }
        student.setClassInfo(classService.getById(student.getClassId()));
        return student;
    }

    /**
     * 设置list中学生的班级信息
     * 
     * @param list
     * @return
     */
    private List<StudentInfo> setClassInfoList(List<StudentInfo> list) {
        for (StudentInfo studentInfo : list) {
            studentInfo = this.setClassInfo(studentInfo);
        }
        return list;
    }

    /**
     * 添加学生并返回学生信息 (因为添加用户的用户名和密码为学号，所以先添加学生,有了userId后修改该学生信息)
     * 
     * @param studentInfo
     * @return
     */
    private StudentInfo insertStudent(StudentInfo studentInfo) {
        studentInfoMapper.insertSelective(studentInfo);
        return this.getById(studentInfo.getId());
    }

    @Override
    public List<StudentInfo> getStudentList(int page, int row) {
        List<StudentInfo> list = studentInfoMapper.selectByPage((page - 1) * row, row);
        return this.setClassInfoList(this.setUserInfoList(list));
    }

    @Override
    public int getTotal() {
        return studentInfoMapper.countByExample(new StudentInfoExample());
    }

    @Override
    public List<StudentInfo> getReadingList() {
        List<StudentInfo> list = studentInfoMapper.selectByExample(new StudentInfoExample());
        // 去掉禁用的学生
        Iterator<StudentInfo> iterator = list.iterator();
        StudentInfo studentInfo = null;
        while (iterator.hasNext()) {
            studentInfo = iterator.next();
            if (studentInfo.getUserInfo().getStatus().equals(false)) {
                iterator.remove();
            }
        }
        return list;
    }

    @Override
    public HSSFWorkbook exportStudent(int totalPage, int pageRow) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = null;
        for (int i = 1; i < totalPage + 1; i++) {
            sheet = workbook.createSheet("学生信息表" + i);
            sheet.setColumnWidth(5, 10 * 256);// 设置第x列的宽度是x个字符宽度
            HSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("学号");
            row.createCell(1).setCellValue("姓名");
            row.createCell(2).setCellValue("性别");
            row.createCell(3).setCellValue("班级");
            row.createCell(4).setCellValue("类别");
            row.createCell(5).setCellValue("状态");
            row.createCell(6).setCellValue("入学日期");
            row.createCell(7).setCellValue("备注");
            List<StudentInfo> list = this.getStudentList(i, pageRow);
            for (int j = 0; j < list.size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(list.get(j).getId());
                row.createCell(1).setCellValue(list.get(j).getUserInfo().getName());
                if (list.get(j).getUserInfo().getSex()) {
                    row.createCell(2).setCellValue("男");
                } else {
                    row.createCell(2).setCellValue("女");
                }
                row.createCell(3).setCellValue(list.get(j).getClassInfo().getName());
                row.createCell(4).setCellValue(list.get(j).getCategory());
                row.createCell(5).setCellValue(list.get(j).getStatus());
                row.createCell(6).setCellValue(list.get(j).getEnrollmentDate());
                row.createCell(7).setCellValue(list.get(j).getRemark());
            }
        }
        return workbook;
    }

    @Override
    public String insertBatchByImport(HSSFWorkbook workbook) {
        Row row = null;
        Cell nameCell = null;
        Cell sexCell = null;
        Cell classCell = null;
        Cell categoryCell = null;
        Cell statusCell = null;
        Cell enrollmentDateCell = null;
        Cell remarkCell = null;
        String className = null;
        String enrollmentDate = null;
        ClassInfo classInfo = null;
        List<StudentInfo> studentList = new ArrayList<>();
        StudentInfo student = null;
        UserInfo user = null;
        
        for (int n = 0; n < workbook.getNumberOfSheets(); n++) {
            HSSFSheet sheet = workbook.getSheetAt(n);
            
            int totalRowNum = sheet.getLastRowNum();
            if (totalRowNum == 0) {
                return "excel中无数据";
            }
            
            Map<String, Integer> headMap = this.studentInfoColumnSort(sheet.getRow(0));
            if (headMap == null) {
                return "excel表头不规范";
            }
            
            for (int i = 1; i < totalRowNum + 1; i++) {
                student = new StudentInfo();
                user = new UserInfo();
                
                row = sheet.getRow(i);
                try {
                    nameCell = row.getCell(headMap.get("name"));
                    sexCell = row.getCell(headMap.get("sex"));
                    classCell = row.getCell(headMap.get("className"));
                    categoryCell = row.getCell(headMap.get("category"));
                    statusCell = row.getCell(headMap.get("status"));
                    enrollmentDateCell = row.getCell(headMap.get("enrollmentDate"));
                    remarkCell = row.getCell(headMap.get("remark"));
                } catch (Exception e) {
                    return "获取单元格错误";
                }
                
                user.setName((String) ExcelUtil.getRightTypeCell(nameCell));
                if (((String) ExcelUtil.getRightTypeCell(sexCell)).equals("男")) {
                    user.setSex(true);
                } else {
                    user.setSex(false);
                }
                student.setUserInfo(user);
                className = (String) ExcelUtil.getRightTypeCell(classCell);
                student.setCategory((String) ExcelUtil.getRightTypeCell(categoryCell));
                student.setStatus((String) ExcelUtil.getRightTypeCell(statusCell));
                student.setRemark((String) ExcelUtil.getRightTypeCell(remarkCell));
                
                enrollmentDate = (String) ExcelUtil.getRightTypeCell(enrollmentDateCell);
                student.setEnrollmentDate(enrollmentDate);
                // 截取入学日期的年份获取班级id
                classInfo = classService.getByNameAndEnrollmentYear(className,
                        Integer.parseInt(enrollmentDate.substring(0, 4)));
                if (classInfo == null) {
                    return "班级不存在";
                }
                student.setClassId(classInfo.getId());
                studentList.add(student);
            }
        }
        try {
            this.insertStudentList(studentList);
        } catch (Exception e) {
            return "添加错误";
        }
        return "SUCCESS";
    }

    /**
     * 学生信息的列排序 ，防止导入的excel列顺序不对
     * 
     * @param rowHead
     * @return
     */
    private Map<String, Integer> studentInfoColumnSort(Row rowHead) {

        int flag = 0;
        Map<String, Integer> headMap = new HashMap<>();
        try {
            // 有7列
            while (flag < 7) {
                Cell cell = rowHead.getCell(flag);
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("姓名")) {
                    headMap.put("name", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("性别")) {
                    headMap.put("sex", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("班级")) {
                    headMap.put("className", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("类别")) {
                    headMap.put("category", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("状态")) {
                    headMap.put("status", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("入学日期")) {
                    headMap.put("enrollmentDate", flag);
                }
                if (ExcelUtil.getRightTypeCell(cell).toString().equals("备注")) {
                    headMap.put("remark", flag);
                }
                flag++;
            }
        } catch (Exception e) {
            return null;
        }
        return headMap;
    }
    
    /**
     * 批量插入学生
     * 
     * @param list
     * @return
     *//*
    private void insertStudentList(List<StudentInfo> list) {
        studentInfoMapper.insertBatch(list);
        List<UserInfo> userList = new ArrayList<>();
        UserInfo user = null;
        for (StudentInfo studentInfo : list) {
            user = studentInfo.getUserInfo();
            user.setUserName(studentInfo.getId().toString());
            user.setPassword(studentInfo.getId().toString());
            user.setStatus(true);
            user.setRoleId(4L);
            userList.add(user);
        }
        userList = userService.insertBatch(userList);
        for (StudentInfo studentInfo : list) {
            for (UserInfo userInfo : userList) {
                if (studentInfo.getUserInfo().getUserName().equals(userInfo.getUserName())) {
                    studentInfo.setUserId(userInfo.getId());
                    break;
                }
            }
        }
        studentInfoMapper.updateBatch(list);
        List<PaymentInfo> paymentList = new ArrayList<>();
        for (StudentInfo studentInfo : list) {
            paymentList.add(chargeItemService.createPaymentInfo(studentInfo));
        }
        paymentInfoService.insertBatch(paymentList);
    }*/

    private void insertStudentList(List<StudentInfo> list) {
        UserInfo userInfo = null;
        for (StudentInfo studentInfo : list) {
            userInfo = studentInfo.getUserInfo();
            userInfo.setStatus(true);
            studentInfo.setUserInfo(userInfo);
            
            this.insert(studentInfo);
        }
    }
    
    @Override
    public int getCountByClassId(Long classId) {
        StudentInfoExample example = new StudentInfoExample();
        example.or().andClassIdEqualTo(classId);
        return studentInfoMapper.countByExample(example);
    }
}
