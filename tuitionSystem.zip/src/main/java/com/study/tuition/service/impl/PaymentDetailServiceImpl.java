package com.study.tuition.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.PaymentDetail;
import com.study.tuition.domain.PaymentDetailExample;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.mapper.PaymentDetailMapper;
import com.study.tuition.service.PaymentDetailService;

@Service
public class PaymentDetailServiceImpl implements PaymentDetailService{

    @Autowired
    private PaymentDetailMapper paymentDetailMapper;
    
    @Override
    public List<PaymentDetail> getListByStudentId(Long studentId) {
        PaymentDetailExample example = new PaymentDetailExample();
        example.or().andStudentIdEqualTo(studentId);
        
        return paymentDetailMapper.selectByExample(example);
    }

    @Override
    public void insert(PaymentDetail paymentDetail) {
        paymentDetailMapper.insertSelective(paymentDetail);
    }

    @Override
    public void update(PaymentDetail paymentDetail) {
        paymentDetailMapper.updateByPrimaryKeySelective(paymentDetail);
    }

    @Override
    public PaymentDetail createPaymentDetail(PaymentInfo paymentInfo) {
        PaymentDetail paymentDetail = new PaymentDetail();
        paymentDetail.setStudentId(paymentInfo.getStudentId());
        paymentDetail.setAmount(paymentInfo.getMoney());
        paymentDetail.setBalance(paymentInfo.getArrear());
        paymentDetail.setPayMethod(paymentInfo.getPayMethod());
        return paymentDetail;
    }

}
