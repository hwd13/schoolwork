package com.study.tuition.service;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.study.tuition.domain.StudentInfo;

public interface StudentService {
    /**
     * 添加学生并且添加缴费信息
     * @param studentInfo
     */
    void insert(StudentInfo studentInfo);
    
    /**
     * 修改学生
     * @param studentInfo
     */
    void update(StudentInfo studentInfo);
    
    /**
     * 通过学生Id返回学生信息
     * @param studentId
     * @return
     */
    StudentInfo getById(Long studentId);
    
    /**
     * 通过班级id获取学生数量
     * @param classId
     * @return
     */
    int getCountByClassId(Long classId);
    
    /**
     * 获取所有学生数目
     * 
     * @return
     */
    int getTotal();
    
    /**
     * 根据页和行返回学生信息
     * 
     * @param page
     * @param row
     * @return
     */
    List<StudentInfo> getStudentList(int page, int row);
    
    /**
     * 获取所有在读学生信息
     * 
     * @return
     */
    List<StudentInfo> getReadingList();
    
    /**
     * 获取所有姓名为name的学生
     * @param name
     * @return
     */
    List<StudentInfo> getListByName(String name);
    
    /**
     * 根据班级编号来获取所有学生
     * 
     * @param classId
     * @return
     */
    List<StudentInfo> getListByClassId(Long classId);
    
    /**
     * 根据专业编号来获取所有学生
     * @param majorId
     * @return
     */
    List<StudentInfo> getListByMajorId(Long majorId);
    
    /**
     * 根据职工编号来获取学生
     * @param employeeId 该职工只能为辅导员
     * @return
     */
    List<StudentInfo> getListByEmployeeId(Long employeeId);
    
    /**
     * 根据系部来获取所有学生
     * 
     * @param departmentName
     * @return
     */
    List<StudentInfo> getListByDepartmentName(String departmentName);
    
    /**
     * 导出学生信息
     * @param totalPage 页数
     * @param pageRow 一页的行数
     * @return
     */
    HSSFWorkbook exportStudent(int totalPage, int pageRow);
    
    /**
     * 导入学生
     * @param workbook
     * @return
     */
    String insertBatchByImport(HSSFWorkbook workbook);
}
