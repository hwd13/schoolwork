package com.study.tuition.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.MajorInfoExample;
import com.study.tuition.mapper.MajorInfoMapper;
import com.study.tuition.service.MajorService;
import com.study.tuition.util.ReturnUtil;

@Service
public class MajorServiceImpl implements MajorService{

    @Autowired
    private MajorInfoMapper majorInfoMapper;
    
    @Override
    public MajorInfo getById(Long majorId) {
        return majorInfoMapper.selectByPrimaryKey(majorId);
    }

    @Override
    public void insert(MajorInfo majorInfo) {
        majorInfoMapper.insertSelective(majorInfo);
    }

    @Override
    public void update(MajorInfo majorInfo) {
        majorInfoMapper.updateByPrimaryKeySelective(majorInfo);
    }

    @Override
    public List<MajorInfo> getListByDepartmentName(String departmentName) {
        MajorInfoExample example = new MajorInfoExample();
        example.or().andDepartmentNameEqualTo(departmentName);
        return majorInfoMapper.selectByExample(example);
    }

    @Override
    public List<MajorInfo> getMajorList(int page, int row) {
        return majorInfoMapper.selectByPage((page - 1) * row, row);
    }

    @Override
    public MajorInfo getMajorByNameAndYear(String name, Integer enrollmentYear) {
        MajorInfoExample example = new MajorInfoExample();
        example.or().andNameEqualTo(name).andEnrollmentYearEqualTo(enrollmentYear);
        List<MajorInfo> list = majorInfoMapper.selectByExample(example);
        return ReturnUtil.returnObject(list);
    }

    @Override
    public int getTotal() {
        return majorInfoMapper.countByExample(new MajorInfoExample());
    }

    @Override
    public List<MajorInfo> getListByName(String name) {
        MajorInfoExample example = new MajorInfoExample();
        example.or().andNameEqualTo(name);
        return majorInfoMapper.selectByExample(example);
    }

}
