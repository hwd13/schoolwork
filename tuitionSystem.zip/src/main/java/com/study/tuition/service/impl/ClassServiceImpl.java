package com.study.tuition.service.impl;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.ClassInfoExample;
import com.study.tuition.domain.EmployeeInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.mapper.ClassInfoMapper;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.EmployeeService;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.PaymentInfoService;
import com.study.tuition.service.StudentService;
import com.study.tuition.service.UserService;
import com.study.tuition.util.ReturnUtil;

@Service
public class ClassServiceImpl implements ClassService{

    @Autowired
    private ClassInfoMapper classInfoMapper;
    @Autowired
    private MajorService majorService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private UserService userService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private PaymentInfoService paymentInfoService;
    
    @Override
    public ClassInfo getById(Long classId) {
        ClassInfo classInfo = classInfoMapper.selectByPrimaryKey(classId);
        return this.setName(classInfo);
    }

    @Override
    public void insert(ClassInfo classInfo) {
        classInfoMapper.insertSelective(classInfo);
    }

    @Override
    public void update(ClassInfo classInfo) {
        classInfoMapper.updateByPrimaryKeySelective(classInfo);
    }

    @Override
    public List<ClassInfo> getListByMajorId(Long majorId) {
        ClassInfoExample example = new ClassInfoExample();
        example.or().andMajorIdEqualTo(majorId);
        List<ClassInfo> list = classInfoMapper.selectByExample(example);
        return this.setNameList(list);
    }

    @Override
    public List<ClassInfo> getListByEmployeeId(Long employeeId) {
        ClassInfoExample example = new ClassInfoExample();
        example.or().andEmployeeIdEqualTo(employeeId);
        List<ClassInfo> list = classInfoMapper.selectByExample(example);
        return this.setNameList(list);
    }

    @Override
    public List<ClassInfo> getList(int page, int row) {
         List<ClassInfo> list = classInfoMapper.selectByPage((page - 1) * row, row);
         list = this.setStudentCountList(list);
         list = this.setTotalAndPaidTuitionList(list);
         return this.setNameList(list);
    }
    
    /**
     * 设置专业名称和辅导员名称
     * 
     * @param classInfo
     * @return
     */
    private ClassInfo setName(ClassInfo classInfo) {
        if (classInfo == null) {
            return null;
        }
     // 设置专业名称
        MajorInfo majorInfo = majorService.getById(classInfo.getMajorId());
        classInfo.setMajorName(majorInfo.getName());
        
        // 设置辅导员名称
        EmployeeInfo employeeInfo = employeeService.getById(classInfo.getEmployeeId());
        UserInfo userInfo = userService.getById(employeeInfo.getUserId());
        classInfo.setEmployeeName(userInfo.getName());
        
        return classInfo;
    }
    
    /**
     * 设置list中专业名称和辅导员名称
     * 
     * @param list
     * @return
     */
    private List<ClassInfo> setNameList(List<ClassInfo> list) {
        MajorInfo majorInfo = null;
        EmployeeInfo employee = null;
        UserInfo userInfo = null;
        for (ClassInfo classInfo : list) {
            // 设置专业名称
            majorInfo = majorService.getById(classInfo.getMajorId());
            classInfo.setMajorName(majorInfo.getName());
            
            // 设置辅导员名称
            employee = employeeService.getById(classInfo.getEmployeeId());
            userInfo = userService.getById(employee.getUserId());
            
            classInfo.setEmployeeName(userInfo.getName());
        }
        return list;
    }

    @Override
    public ClassInfo getByNameAndEnrollmentYear(String name, Integer enrollmentYear) {
        ClassInfoExample example = new ClassInfoExample();
        example.or().andNameEqualTo(name).andEnrollmentYearEqualTo(enrollmentYear);
        List<ClassInfo> list = classInfoMapper.selectByExample(example);
        
        ClassInfo classInfo = ReturnUtil.returnObject(list);
        return this.setName(classInfo);
    }

    @Override
    public int getTotal() {
        return classInfoMapper.countByExample(new ClassInfoExample());
    }

    @Override
    public List<ClassInfo> getlistByName(String name) {
        ClassInfoExample example = new ClassInfoExample();
        example.or().andNameEqualTo(name);
        List<ClassInfo> list = classInfoMapper.selectByExample(example);
        return this.setNameList(list);
    }

    @Override
    public List<ClassInfo> getListByMajorIdAndYear(Long majorId, Integer enrollmentYear) {
        ClassInfoExample example = new ClassInfoExample();
        example.or().andMajorIdEqualTo(majorId).andEnrollmentYearEqualTo(enrollmentYear);
        return this.setNameList(classInfoMapper.selectByExample(example));
    }

    /**
     * 设置一个班级中学生的数量
     * 
     * @param classInfo
     * @return
     */
    private ClassInfo setStudentCount(ClassInfo classInfo) {
        classInfo.setStudentCount(studentService.getCountByClassId(classInfo.getId()));
        return classInfo;
    }
    
    /**
     * 设置班级中的学生数量
     * 
     * @param list
     * @return
     */
    private List<ClassInfo> setStudentCountList(List<ClassInfo> list) {
        for (ClassInfo classInfo : list) {
            classInfo = this.setStudentCount(classInfo);
        }
        return list;
    }
    
    /**
     * 设置一个班级中应交学费和实缴学费
     * 
     * @param classInfo
     * @return
     */
    private ClassInfo setTotalAndPaidTuition(ClassInfo classInfo) {
        List<PaymentInfo> list = paymentInfoService.getListByClassId(classInfo.getId());
        int totalTuition = 0;
        int paidTuition = 0;
        for (PaymentInfo paymentInfo : list) {
            totalTuition += paymentInfo.getTuition();
            paidTuition += paymentInfo.getTuition() - paymentInfo.getArrear();
        }
        classInfo.setPaySchoolYear(list.get(0).getSchoolYear());
        classInfo.setTotalTuition(totalTuition);
        classInfo.setPaidTuition(paidTuition);
        return classInfo;
    }
    
    /**
     * 设置所有班级中应交学费和实缴学费
     * @param list
     * @return
     */
    private List<ClassInfo> setTotalAndPaidTuitionList(List<ClassInfo> list) {
        for (ClassInfo classInfo : list) {
            classInfo = this.setTotalAndPaidTuition(classInfo);
        }
        return list;
    }

    @Override
    public HSSFWorkbook exportPaymentInfo(int totalPage, int pageRow) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = null;
        for (int i = 1; i < totalPage + 1; i++) {
            sheet = workbook.createSheet("缴费情况统计表" + i);
            sheet.setColumnWidth(0, 20 * 256);// 设置第x列的宽度是x个字符宽度
            HSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("专业");
            row.createCell(1).setCellValue("班级");
            row.createCell(2).setCellValue("入学年份");
            row.createCell(3).setCellValue("学年");
            row.createCell(4).setCellValue("应缴学费");
            row.createCell(5).setCellValue("实缴学费");
            List<ClassInfo> list = this.getList(i, pageRow);
            for (int j = 0; j < list.size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(list.get(j).getMajorName());
                row.createCell(1).setCellValue(list.get(j).getName());
                row.createCell(2).setCellValue(list.get(j).getEnrollmentYear());
                row.createCell(3).setCellValue(list.get(j).getPaySchoolYear());
                row.createCell(4).setCellValue(list.get(j).getTotalTuition() / 100 + "元");
                row.createCell(5).setCellValue(list.get(j).getPaidTuition() / 100 + "元");
            }
        }
        return workbook;
    }

    @Override
    public HSSFWorkbook exportArrearClassInfo(int totalPage, int pageRow) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = null;
        for (int i = 1; i < totalPage + 1; i++) {
            sheet = workbook.createSheet("欠费情况统计表" + i);
            sheet.setColumnWidth(0, 20 * 256);// 设置第x列的宽度是x个字符宽度
            HSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("专业");
            row.createCell(1).setCellValue("班级");
            row.createCell(2).setCellValue("入学年份");
            row.createCell(3).setCellValue("学年");
            row.createCell(4).setCellValue("欠费金额");
            List<ClassInfo> list = this.getList(i, pageRow);
            for (int j = 0; j < list.size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(list.get(j).getMajorName());
                row.createCell(1).setCellValue(list.get(j).getName());
                row.createCell(2).setCellValue(list.get(j).getEnrollmentYear());
                row.createCell(3).setCellValue(list.get(j).getPaySchoolYear());
                row.createCell(4).setCellValue((list.get(j).getTotalTuition() - list.get(j).getPaidTuition()) / 100 + "元");
            }
        }
        return workbook;
    }

    @Override
    public HSSFWorkbook exportStudentCount(int totalPage, int pageRow) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = null;
        for (int i = 1; i < totalPage + 1; i++) {
            sheet = workbook.createSheet("学生信息统计表" + i);
            sheet.setColumnWidth(0, 20 * 256);// 设置第x列的宽度是x个字符宽度
            HSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("专业");
            row.createCell(1).setCellValue("班级");
            row.createCell(2).setCellValue("入学年份");
            row.createCell(3).setCellValue("人数");
            List<ClassInfo> list = this.getList(i, pageRow);
            for (int j = 0; j < list.size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(list.get(j).getMajorName());
                row.createCell(1).setCellValue(list.get(j).getName());
                row.createCell(2).setCellValue(list.get(j).getEnrollmentYear());
                row.createCell(3).setCellValue(list.get(j).getStudentCount());
            }
        }
        return workbook;
    }

}
