package com.study.tuition.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.EmployeeInfo;
import com.study.tuition.domain.EmployeeInfoExample;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.mapper.EmployeeInfoMapper;
import com.study.tuition.service.EmployeeService;
import com.study.tuition.service.UserService;
import com.study.tuition.util.ReturnUtil;

@Service
public class EmployeeServicImpl implements EmployeeService{

    @Autowired
    private EmployeeInfoMapper employeeInfoMapper;
    @Autowired
    private UserService userService;
    
    @Override
    public void insert(EmployeeInfo employeeInfo) {
        UserInfo userInfo = employeeInfo.getUserInfo();
        Long userId = userService.insert(userInfo);
        employeeInfo.setUserId(userId);
        employeeInfoMapper.insertSelective(employeeInfo);
    }

    @Override
    public void update(EmployeeInfo employeeInfo) {
        employeeInfoMapper.updateByPrimaryKeySelective(employeeInfo);
    }

    @Override
    public EmployeeInfo getById(Long employeeId) {
        EmployeeInfo employeeInfo = employeeInfoMapper.selectByPrimaryKey(employeeId);
        return this.setUserInfo(employeeInfo);
    }

    /*@Override
    public List<EmployeeInfo> getListByName(String employeeName) {
        List<EmployeeInfo> employeeList = new ArrayList<>();
        List<UserInfo> nameList = userService.getByName(employeeName);
        if (nameList.isEmpty()) {
            return employeeList;
        }
        Iterator<UserInfo> iterator = nameList.iterator();
        // 去除学生
        while (iterator.hasNext()) {
            UserInfo userInfo = iterator.next();
            // 4 为学生
            if (userInfo.getRoleId() == 4) {
                iterator.remove();
            }
        }
        if (nameList.isEmpty()) {
            return employeeList;
        }
        EmployeeInfoExample example = new EmployeeInfoExample();
        for (UserInfo user : nameList) {
            example.or().andUserIdEqualTo(user.getId());
            employeeList.addAll(employeeInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setUserInfoList(employeeList);
    }*/

    @Override
    public List<EmployeeInfo> getListByName(String employeeName) {
        List<UserInfo> list = userService.getEmployeeUserList();
        List<EmployeeInfo> employeeList = new ArrayList<>();
        
        EmployeeInfoExample example = new EmployeeInfoExample();
        
        EmployeeInfo employeeInfo = null;
        for (UserInfo user : list) {
            example.or().andUserIdEqualTo(user.getId());
            if (employeeName.equals(user.getName())) {
                example.or().andUserIdEqualTo(user.getId());
                // 因为用户id唯一,所以返回第一个数据
                employeeInfo = ReturnUtil.returnObject(employeeInfoMapper.selectByExample(example));
                employeeList.add(employeeInfo);
                
                example.clear();
            }
        }
        return this.setUserInfoList(employeeList);
    }
    
    /**
     * 设置职工的用户信息
     * 
     * @param employee
     * @return
     */
    private EmployeeInfo setUserInfo(EmployeeInfo employee) {
        if (employee == null) {
            return null;
        }
        UserInfo userInfo = userService.getById(employee.getUserId());
        employee.setUserInfo(userInfo);
        return employee;
    }
    
    /**
     * 设置list中职工的用户信息
     * 
     * @param list
     * @return
     */
    private List<EmployeeInfo> setUserInfoList(List<EmployeeInfo> list) {
        UserInfo userInfo = null;
        for (EmployeeInfo employeeInfo : list) {
            userInfo = userService.getById(employeeInfo.getUserId());
            employeeInfo.setUserInfo(userInfo);
        }
        return list;
    }

    @Override
    public List<EmployeeInfo> getEmployeeList(int page, int row) {
        List<EmployeeInfo> list = employeeInfoMapper.selectByPage((page - 1) * row, row);
        return this.setUserInfoList(list);
    }
    
    @Override
    public int getTotal() {
        return employeeInfoMapper.countByExample(new EmployeeInfoExample());
    }
}
