package com.study.tuition.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentDetail;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.PaymentInfoExample;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.mapper.PaymentInfoMapper;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.PaymentDetailService;
import com.study.tuition.service.PaymentInfoService;
import com.study.tuition.service.StudentService;
import com.study.tuition.util.ReturnUtil;

@Service
public class PaymentInfoServiceImpl implements PaymentInfoService {

    @Autowired
    private PaymentInfoMapper paymentInfoMapper;
    @Autowired
    private StudentService studentService;
    @Autowired
    private MajorService majorService;
    @Autowired
    private PaymentDetailService paymentDetailService;

    @Override
    public PaymentInfo getById(Long id) {
        PaymentInfo paymentInfo = paymentInfoMapper.selectByPrimaryKey(id);
        return this.setPaymentAttribute(paymentInfo);
    }

    @Override
    public void insert(PaymentInfo paymentInfo) {
        paymentInfoMapper.insertSelective(paymentInfo);
    }

    @Override
    public void update(PaymentInfo paymentInfo) {
        paymentInfoMapper.updateByPrimaryKeySelective(paymentInfo);
    }

    @Override
    public PaymentInfo getByStudentId(Long studentId) {
        PaymentInfoExample example = new PaymentInfoExample();
        example.or().andStudentIdEqualTo(studentId);
        List<PaymentInfo> list = paymentInfoMapper.selectByExample(example);
        return this.setPaymentAttribute(ReturnUtil.returnObject(list));
    }

    @Override
    public PaymentInfo getArrearByStudentId(Long studentId) {
        PaymentInfo paymentInfo = this.getByStudentId(studentId);
        if (paymentInfo == null) {
            return null;
        }
        if (paymentInfo.getPayStatus()) {
            return null;
        } else {
            return this.setPaymentAttribute(paymentInfo);
        }
    }

    @Override
    public List<PaymentInfo> getListByName(String name) {
        List<StudentInfo> studentList = studentService.getListByName(name);
        if (studentList.isEmpty()) {
            return null;
        }
        List<PaymentInfo> paymentList = new ArrayList<>();
        PaymentInfoExample example = new PaymentInfoExample();
        for (StudentInfo student : studentList) {
            example.or().andStudentIdEqualTo(student.getId());
            paymentList.addAll(paymentInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getArrearListByName(String name) {
        List<PaymentInfo> paymentList = this.getListByName(name);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getListByClassId(Long classId) {
        List<StudentInfo> oneClassStudentList = studentService.getListByClassId(classId);
        if (oneClassStudentList.isEmpty()) {
            return null;
        }
        List<PaymentInfo> paymentList = new ArrayList<>();
        PaymentInfoExample example = new PaymentInfoExample();
        for (StudentInfo student : oneClassStudentList) {
            example.or().andStudentIdEqualTo(student.getId());
            paymentList.addAll(paymentInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getArrearListByClassId(Long classId) {
        List<PaymentInfo> paymentList = this.getListByClassId(classId);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getListByMajorId(Long majorId) {
        List<StudentInfo> oneMajorStudentList = studentService.getListByMajorId(majorId);
        if (oneMajorStudentList.isEmpty()) {
            return null;
        }
        List<PaymentInfo> paymentList = new ArrayList<>();
        PaymentInfoExample example = new PaymentInfoExample();
        for (StudentInfo student : oneMajorStudentList) {
            example.or().andStudentIdEqualTo(student.getId());
            paymentList.addAll(paymentInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getArrearListByMajorId(Long majorId) {
        List<PaymentInfo> paymentList = this.getListByMajorId(majorId);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getListBySchoolYear(Integer schoolYear) {
        PaymentInfoExample example = new PaymentInfoExample();
        example.or().andSchoolYearEqualTo(schoolYear);
        return paymentInfoMapper.selectByExample(example);
    }

    @Override
    public List<PaymentInfo> getArrearListBySchoolYear(Integer schoolYear) {
        List<PaymentInfo> paymentList = this.getListBySchoolYear(schoolYear);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getListByEmployeeId(Long employeeId) {
        List<StudentInfo> oneEmployeeStudentList = studentService.getListByEmployeeId(employeeId);
        if (oneEmployeeStudentList.isEmpty()) {
            return null;
        }

        List<PaymentInfo> paymentList = new ArrayList<>();
        PaymentInfoExample example = new PaymentInfoExample();
        for (StudentInfo student : oneEmployeeStudentList) {
            example.or().andStudentIdEqualTo(student.getId());
            paymentList.addAll(paymentInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getArrearListByEmployeeId(Long employeeId) {
        List<PaymentInfo> paymentList = this.getListByEmployeeId(employeeId);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getListByDepartmentName(String departmentName) {
        List<StudentInfo> studentList = studentService.getListByDepartmentName(departmentName);
        if (studentList.isEmpty()) {
            return null;
        }

        List<PaymentInfo> paymentList = new ArrayList<>();
        PaymentInfoExample example = new PaymentInfoExample();
        for (StudentInfo student : studentList) {
            example.or().andStudentIdEqualTo(student.getId());
            paymentList.addAll(paymentInfoMapper.selectByExample(example));
            example.clear();
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getArrearListByDepartmentName(String departmentName) {
        List<PaymentInfo> paymentList = this.getListByDepartmentName(departmentName);
        if (paymentList == null) {
            return null;
        }
        Iterator<PaymentInfo> iterator = paymentList.iterator();
        while (iterator.hasNext()) {
            PaymentInfo paymentInfo = iterator.next();
            if (paymentInfo.getPayStatus()) {
                iterator.remove();
            }
        }
        return this.setPaymentAttributeList(paymentList);
    }

    @Override
    public List<PaymentInfo> getPaymentInfoList(int page, int row) {
        List<PaymentInfo> list = paymentInfoMapper.selectByPage((page - 1) * row, row);
        return this.setPaymentAttributeList(list);
    }

    /**
     * 设置缴费信息中的属性 : 学生信息-->(用户信息，班级信息)
     * 
     * @param paymentInfo
     * @return
     */
    private PaymentInfo setPaymentAttribute(PaymentInfo paymentInfo) {
        if (paymentInfo == null) {
            return null;
        }
        StudentInfo studentInfo = studentService.getById(paymentInfo.getStudentId());
        if (studentInfo == null) {
            return null;
        }
        MajorInfo majorInfo = majorService.getById(studentInfo.getClassInfo().getMajorId());
        paymentInfo.setDepartmentName(majorInfo.getDepartmentName());
        paymentInfo.setStudentInfo(studentInfo);
        return paymentInfo;
    }

    /**
     * 设置list缴费信息中的属性 : 学生信息-->(用户信息，班级信息)
     * 
     * @param paymentInfo
     * @param list
     * @return
     */
    private List<PaymentInfo> setPaymentAttributeList(List<PaymentInfo> list) {
        for (PaymentInfo paymentInfo : list) {
            paymentInfo = this.setPaymentAttribute(paymentInfo);
        }
        return list;
    }

    @Override
    public void updateAndAddDetail(PaymentInfo paymentInfo, PaymentDetail paymentDetail) {
        this.update(paymentInfo);
        paymentDetailService.insert(paymentDetail);
    }

    @Override
    public int getTotal() {
        return paymentInfoMapper.countByExample(new PaymentInfoExample());
    }

    @Override
    public HSSFWorkbook exportPaymentInfo(int totalPage, int pageRow) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = null;
        for (int i = 1; i < totalPage + 1; i++) {
            sheet = workbook.createSheet("缴费信息表" + i);
            HSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("学号");
            row.createCell(1).setCellValue("学费");
            row.createCell(2).setCellValue("欠费金额");
            row.createCell(3).setCellValue("学年");
            row.createCell(4).setCellValue("分期次数");
            row.createCell(5).setCellValue("缴费状态");
            List<PaymentInfo> list = this.getPaymentInfoList(i, pageRow);
            for (int j = 0; j < list.size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(list.get(j).getStudentInfo().getId());
                row.createCell(1).setCellValue(list.get(j).getTuition());
                row.createCell(2).setCellValue(list.get(j).getArrear());
                row.createCell(3).setCellValue(list.get(j).getSchoolYear());
                row.createCell(4).setCellValue(list.get(j).getHirePurchaseCount());
                if (list.get(j).getPayStatus()) {
                    row.createCell(5).setCellValue("已付清");
                } else {
                    row.createCell(5).setCellValue("未付清");
                }
            }
        }
        return workbook;
    }

    @Override
    public List<PaymentInfo> getArrearPaymentInfoList(int page, int row) {
        List<PaymentInfo> list = paymentInfoMapper.selectArrearByPage((page - 1) * row, row);
        return this.setPaymentAttributeList(list);
    }

    @Override
    public void insertBatch(List<PaymentInfo> list) {
        paymentInfoMapper.insertBatch(list);
    }
}
