package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.RoleMenu;

public interface RoleMenuService {
    /**
     * 通过角色ID返回所有该角色的菜单ID
     * @param roleId
     * @return
     */
    List<Long> getMenuIdListByRoleId(Long roleId);
    
    /**
     * 获取角色菜单信息
     * 
     * @return
     */
    List<RoleMenu> getRoleMenu();
    
    /**
     * 添加菜单或者按钮
     * @param roleMenu
     */
    void insert(RoleMenu roleMenu);
    
    /**
     * 修改菜单或者按钮
     * @param roleMenu
     */
    void update(RoleMenu roleMenu);
    
    /**
     * 根据角色id编辑角色的角色菜单
     * @param roleId
     * @param menuIdList
     */
    void updateRoleMenu(Long roleId, List<Long> menuIdList);
}
