package com.study.tuition.service.impl;

import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Log {
	//log4j 日志记录
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	public Object logging(ProceedingJoinPoint pjp){
		Object result = null;
		try {
			result = pjp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		log.info(pjp.getSignature().getName()+"被调用");
		return result;
	}
}
