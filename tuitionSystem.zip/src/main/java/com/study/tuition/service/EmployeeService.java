package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.EmployeeInfo;

public interface EmployeeService {
    /**
     * 添加职工
     * @param employeeInfo
     */
    void insert(EmployeeInfo employeeInfo);
    
    /**
     * 修改职工
     * @param employeeInfo
     */
    void update(EmployeeInfo employeeInfo);
    
    /**
     * 通过职工Id返回职工信息
     * @param employeeId
     * @return
     */
    EmployeeInfo getById(Long employeeId);
    
    /**
     * 根据页和行返回职工信息
     * 
     * @return
     */
    List<EmployeeInfo> getEmployeeList(int page, int row);
    
    /**
     * 获取所有职工的数量
     * 
     * @return
     */
    int getTotal();
    
    /**
     * 根据职工姓名来获取职工
     * 
     * @param employeeName
     * @return
     */
    List<EmployeeInfo> getListByName(String employeeName);
}
