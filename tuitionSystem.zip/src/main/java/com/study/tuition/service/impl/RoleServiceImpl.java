package com.study.tuition.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.RoleInfo;
import com.study.tuition.domain.RoleInfoExample;
import com.study.tuition.domain.RoleMenu;
import com.study.tuition.mapper.RoleInfoMapper;
import com.study.tuition.service.RoleMenuService;
import com.study.tuition.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService{

    @Autowired
    private RoleInfoMapper roleInfoMapper;
    @Autowired
    private RoleMenuService roleMenuService;
    
    @Override
    public RoleInfo getById(Long id) {
        return roleInfoMapper.selectByPrimaryKey(id);
    }

    @Override
    public void insert(RoleInfo roleInfo, List<Long> menuIdList) {
        roleInfoMapper.insertSelective(roleInfo);
        RoleMenu roleMenu = null;
        for (Long menuId : menuIdList) {
            roleMenu = new RoleMenu();
            roleMenu.setRoleId(roleInfo.getId());
            roleMenu.setMenuId(menuId);
            roleMenuService.insert(roleMenu);
        }
    }

    @Override
    public void update(RoleInfo roleInfo) {
        roleInfoMapper.updateByPrimaryKeySelective(roleInfo);
    }

    @Override
    public List<RoleInfo> getRoleList() {
        return roleInfoMapper.selectByExample(new RoleInfoExample());
    }

}
