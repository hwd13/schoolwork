package com.study.tuition.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.MenuInfo;
import com.study.tuition.domain.RoleInfo;
import com.study.tuition.domain.RoleMenu;
import com.study.tuition.domain.RoleMenuExample;
import com.study.tuition.mapper.RoleMenuMapper;
import com.study.tuition.service.MenuInfoService;
import com.study.tuition.service.RoleMenuService;
import com.study.tuition.service.RoleService;

@Service
public class RoleMenuServiceImpl implements RoleMenuService{

    @Autowired
    private RoleMenuMapper roleMenuMapper;
    @Autowired
    private RoleService roleService;
    @Autowired
    private MenuInfoService menuInfoService;
    
    @Override
    public List<Long> getMenuIdListByRoleId(Long roleId) {
        RoleMenuExample example = new RoleMenuExample();
        if (roleId != null) {
            example.or().andRoleIdEqualTo(roleId);
        }
        List<RoleMenu> list = roleMenuMapper.selectByExample(example);
        
        List<Long> menuIdList = new ArrayList<>();
        for (RoleMenu roleMenu : list) {
            menuIdList.add(roleMenu.getMenuId());
        }
        return menuIdList;
    }

    @Override
    public void insert(RoleMenu roleMenu) {
        roleMenuMapper.insertSelective(roleMenu);
    }

    @Override
    public void update(RoleMenu roleMenu) {
        roleMenuMapper.updateByPrimaryKeySelective(roleMenu);
    }

    @Override
    public List<RoleMenu> getRoleMenu() {
        List<RoleMenu> list = roleMenuMapper.selectByExample(new RoleMenuExample());
        List<RoleInfo> roleList = roleService.getRoleList();
        List<MenuInfo> menuList = new ArrayList<>();
        
        for (RoleInfo roleInfo : roleList) {
            menuList = menuInfoService.getMenuListByRoleId(roleInfo.getId());
        }
        
        list = this.setRoleName(list, roleList);
        list = this.setMenuName(list, menuList);
        
        return list;
    }

    /**
     * 设置角色菜单中的角色名称
     * 
     * @param list
     * @param roleList
     * @return
     */
    private List<RoleMenu> setRoleName(List<RoleMenu> list, List<RoleInfo> roleList) {
        for (RoleMenu roleMenu : list) {
            for (RoleInfo roleInfo : roleList) {
                if (roleMenu.getRoleId().equals(roleInfo.getId())) {
                    roleMenu.setRoleName(roleInfo.getName());
                    continue;
                }
            }
        }
        return list;
    }
    
    /**
     * 设置角色菜单中的菜单名称
     * 
     * @param list
     * @param menuList
     * @return
     */
    private List<RoleMenu> setMenuName(List<RoleMenu> list, List<MenuInfo> menuList) {
        for (RoleMenu roleMenu : list) {
            for (MenuInfo menuInfo : menuList) {
                if (roleMenu.getMenuId().equals(menuInfo.getId())) {
                    roleMenu.setMenuName(menuInfo.getName());
                    continue;
                }
            }
        }
        return list;
    }

    @Override
    public void updateRoleMenu(Long roleId, List<Long> menuIdList) {
        roleMenuMapper.deleteByRoleId(roleId);
        RoleMenu roleMenu = null;
        for (Long menuId : menuIdList) {
            roleMenu = new RoleMenu();
            roleMenu.setRoleId(roleId);
            roleMenu.setMenuId(menuId);
            roleMenuMapper.insertSelective(roleMenu);
        }
    }
}
