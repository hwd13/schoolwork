package com.study.tuition.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.MenuInfo;
import com.study.tuition.domain.MenuInfoExample;
import com.study.tuition.mapper.MenuInfoMapper;
import com.study.tuition.service.MenuInfoService;
import com.study.tuition.service.RoleMenuService;
import com.study.tuition.util.ReturnUtil;

@Service
public class MenuInfoServiceImpl implements MenuInfoService {

    @Autowired
    private MenuInfoMapper menuInfoMapper;
    @Autowired
    private RoleMenuService roleMenuService;

    @Override
    public List<MenuInfo> getMenuListByRoleId(Long roleId) {
        // 第一级的list
        List<MenuInfo> firstStageList = new ArrayList<>();
        List<Long> menuIdList = roleMenuService.getMenuIdListByRoleId(roleId);
        List<MenuInfo> menuList = this.getByIdList(menuIdList);

        Iterator<MenuInfo> iterator = menuList.iterator();
        while (iterator.hasNext()) {
            MenuInfo menuInfo = iterator.next();
            if (menuInfo.getParentId().equals(0L) && menuInfo.getMenuType()) {
                menuInfo.setChildrenMenu(new ArrayList<MenuInfo>());
                firstStageList.add(menuInfo);
                iterator.remove();
            }
        }
        firstStageList = this.setSecondLevel(firstStageList, menuList, roleId);
        return firstStageList;
    }

    /**
     * 将所有二级菜单放入一级菜单中
     * 
     * @param firstStageList
     *            第一及菜单
     * @param list
     *            二级菜单
     * @param roleId
     * @return
     */
    private List<MenuInfo> setSecondLevel(List<MenuInfo> firstStageList, List<MenuInfo> list, Long roleId) {
        Iterator<MenuInfo> firstStageIterator = firstStageList.iterator();
        List<MenuInfo> buttonList = null;
        if (roleId == null) {
            buttonList = this.getButtonList();
        } else {
            buttonList = this.getButtonByRoleId(roleId);
        }
        
        // 迭代一级菜单
        while (firstStageIterator.hasNext()) {
            MenuInfo parentMenu = firstStageIterator.next();
            Iterator<MenuInfo> iterator = list.iterator();

            // 迭代二级菜单
            while (iterator.hasNext()) {
                MenuInfo menuInfo = iterator.next();
                Long parentId = menuInfo.getParentId();
                Boolean isMenu = menuInfo.getMenuType();

                if (parentId.equals(parentMenu.getId()) && isMenu) {
                    List<MenuInfo> childrenMenuList = parentMenu.getChildrenMenu();
                    // 二级菜单的按钮
                    menuInfo = this.setMenuButton(menuInfo, buttonList);
                    childrenMenuList.add(menuInfo);
                    parentMenu.setChildrenMenu(childrenMenuList);

                    iterator.remove();
                }
            }
        }

        return firstStageList;
    }

    @Override
    public List<MenuInfo> getByIdList(List<Long> list) {
        MenuInfoExample example = new MenuInfoExample();
        example.or().andIdIn(list);
        return menuInfoMapper.selectByExample(example);
    }

    @Override
    public List<MenuInfo> getButtonByRoleId(Long roleId) {
        List<Long> list = roleMenuService.getMenuIdListByRoleId(roleId);
        List<MenuInfo> buttonList = new ArrayList<>();
        MenuInfoExample example = new MenuInfoExample();
        MenuInfo button = null;
        for (Long menuId : list) {
            example.or().andIdEqualTo(menuId).andMenuTypeEqualTo(false);
            button = ReturnUtil.returnObject(menuInfoMapper.selectByExample(example));
            if (button != null) {
                buttonList.add(button);
            }
            example.clear();
        }
        return buttonList;
    }

    @Override
    public List<MenuInfo> getMenuList() {
        return this.getMenuListByRoleId(null);
    }

    @Override
    public List<MenuInfo> setCheckedMenuList(Long roleId) {
        List<MenuInfo> menuList = this.getMenuList();
        List<Long> menuIdList = roleMenuService.getMenuIdListByRoleId(roleId);
        List<MenuInfo> checkedMenuList = this.getByIdList(menuIdList);
//        List<MenuInfo> checkedMenuList = this.getMenuListByRoleId(roleId);
        return this.setCheckedMenu(menuList, checkedMenuList);
    }

    @Override
    public List<MenuInfo> getButtonList() {
        MenuInfoExample example = new MenuInfoExample();
        example.or().andMenuTypeEqualTo(false);
        return menuInfoMapper.selectByExample(example);
    }
    
    /**
     * 设置菜单的按钮
     * 
     * @param menuInfo
     * @param buttonList
     * @return
     */
    private MenuInfo setMenuButton(MenuInfo menuInfo, List<MenuInfo> buttonList) {
        List<MenuInfo> menuButtonList = new ArrayList<>();
        for (MenuInfo button : buttonList) {
            if (button.getParentId().equals(menuInfo.getId())) {
                menuButtonList.add(button);
            }
        }
        menuInfo.setButtonList(menuButtonList);
        return menuInfo;
    }
    
    /**
     * 设置被选择的菜单
     * 
     * @param list
     * @param checkedMenuList
     * @return
     */
    private List<MenuInfo> setCheckedMenu(List<MenuInfo> list, List<MenuInfo> checkedMenuList) {
        for (MenuInfo menuInfo : list) {
            for (MenuInfo checkedMenu : checkedMenuList) {
                if (checkedMenu.getId().equals(menuInfo.getId())) {
                    menuInfo.setIsCheck(true);
                    if (menuInfo.getChildrenMenu() != null) {
                        menuInfo.setChildrenMenu(this.setCheckedMenu(menuInfo.getChildrenMenu(), checkedMenuList));
                    } else if (menuInfo.getButtonList() != null) {
                        menuInfo.setChildrenMenu(this.setCheckedMenu(menuInfo.getButtonList(), checkedMenuList));
                    }
                }
            }
        }
        return list;
    }
}
