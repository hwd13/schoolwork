package com.study.tuition.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.tuition.domain.RoleInfo;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.domain.UserInfoExample;
import com.study.tuition.mapper.UserInfoMapper;
import com.study.tuition.service.RoleService;
import com.study.tuition.service.UserService;
import com.study.tuition.util.MD5;
import com.study.tuition.util.ReturnUtil;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private RoleService roleService;
    
    private static final String SALT = "z25gc36O70wnV4S6";
    /*
     * 密码单向加密
     */
    private String getEncryptPassword(String password){
        return MD5.getMessageDigest(SALT + password);
    }
    
    @Override
    public boolean checkLogin(String userName, String password) {
        UserInfo userInfo = this.getByUserName(userName);
        if (userInfo == null) {
            return false;
        }
        String encryptPassword = this.getEncryptPassword(password);

        boolean isLogin = userInfo.getPassword().equals(encryptPassword);
        return isLogin;
    }

    @Override
    public UserInfo getById(Long userId) {
        UserInfo userInfo = userInfoMapper.selectByPrimaryKey(userId);
        return this.setRoleName(userInfo);
    }

    @Override
    public Long insert(UserInfo userInfo) {
        String encryptPassword = this.getEncryptPassword(userInfo.getPassword());
        userInfo.setPassword(encryptPassword);
        userInfoMapper.insertSelective(userInfo);
        return userInfo.getId();
    }

    @Override
    public void update(UserInfo userInfo) {
        String encryptPassword = getEncryptPassword(userInfo.getPassword());
        userInfo.setPassword(encryptPassword);
        userInfoMapper.updateByPrimaryKeySelective(userInfo);
    }

    @Override
    public UserInfo getByUserName(String userName) {
        UserInfoExample example = new UserInfoExample();
        example.or().andUserNameEqualTo(userName);
        List<UserInfo> list = userInfoMapper.selectByExample(example);

        UserInfo userInfo = ReturnUtil.returnObject(list);
        return this.setRoleName(userInfo);
    }

    @Override
    public boolean checkPassowrd(UserInfo userInfo, String password) {
        String encryptPassword = this.getEncryptPassword(password);
        return encryptPassword.equals(userInfo.getPassword());
    }

    @Override
    public List<UserInfo> getByName(String name) {
        UserInfoExample example = new UserInfoExample();
        example.or().andNameEqualTo(name);
        List<UserInfo> list = userInfoMapper.selectByExample(example);
        return this.setRoleNameList(list);
    }

    @Override
    public List<UserInfo> getUserList(int page, int row) {
        List<UserInfo> list = userInfoMapper.selectByPage((page - 1) * row, row);
        return this.setRoleNameList(list);
    }
    
    /**
     * 设置角色名称
     * 
     * @param userInfo
     * @return
     */
    private UserInfo setRoleName(UserInfo userInfo) {
        if (userInfo == null) {
            return null;
        }
        RoleInfo roleInfo = roleService.getById(userInfo.getRoleId());
        userInfo.setRoleName(roleInfo.getName());
        return userInfo;
    }
    
    /**
     * 设置list中的角色名称
     * 
     * @param list
     * @return
     */
    private List<UserInfo> setRoleNameList(List<UserInfo> list) {
        for (UserInfo userInfo : list) {
            userInfo = this.setRoleName(userInfo);
        }
        return list;
    }

    @Override
    public List<UserInfo> getStudentUserList() {
        UserInfoExample example = new UserInfoExample();
        example.or().andRoleIdEqualTo(4L);
        List<UserInfo> list = userInfoMapper.selectByExample(example);
        return this.setRoleNameList(list);
    }

    @Override
    public List<UserInfo> getEmployeeUserList() {
        UserInfoExample example = new UserInfoExample();
        example.or().andRoleIdNotEqualTo(4L);
        List<UserInfo> list = userInfoMapper.selectByExample(example);
        return this.setRoleNameList(list);
    }

    @Override
    public int getTotal() {
        return userInfoMapper.countByExample(new UserInfoExample());
    }

    @Override
    public List<UserInfo> insertBatch(List<UserInfo> list) {
        String encryptPassword = null;
        for (UserInfo userInfo : list) {
            encryptPassword = this.getEncryptPassword(userInfo.getPassword());
            userInfo.setPassword(encryptPassword);
        }
        userInfoMapper.insertBatch(list);
        return list;
    }
}
