package com.study.tuition.service;

import java.util.List;

import com.study.tuition.domain.RoleInfo;

public interface RoleService {
    /**
     * 根据id获取角色
     * 
     * @param id
     * @return
     */
    RoleInfo getById(Long id);

    /**
     * 返回所有的角色
     * 
     * @return
     */
    List<RoleInfo> getRoleList();
    
    /**
     * 添加角色 
     * @param roleInfo
     * @param menuIdList 角色需要的菜单id
     */
    void insert(RoleInfo roleInfo, List<Long> menuIdList);

    /**
     * 更新角色信息
     * @param roleInfo
     */
    void update(RoleInfo roleInfo);
}
