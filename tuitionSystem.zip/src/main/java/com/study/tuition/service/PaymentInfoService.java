package com.study.tuition.service;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.study.tuition.domain.PaymentDetail;
import com.study.tuition.domain.PaymentInfo;

public interface PaymentInfoService {
    /**
     * 通过支付信息Id返回支付信息
     * @param id
     * @return
     */
    PaymentInfo getById(Long id);
    
    /**
     * 获取缴费信息的总条数
     * @return
     */
    int getTotal();
    
    /**
     * 根据学号获取缴费信息
     * @param studentId
     * @return
     */
    PaymentInfo getByStudentId(Long studentId);
    
    /**
     * 根据学号获取欠费的缴费信息
     * 
     * @param studentId
     * @return
     */
    PaymentInfo getArrearByStudentId(Long studentId);
    
    /**
     * 根据页和行来返回数据
     * @param page
     * @param row
     * @return
     */
    List<PaymentInfo> getPaymentInfoList(int page, int row);
    
    /**
     * 根据页和行来返回欠费数据
     * @param page
     * @param row
     * @return
     */
    List<PaymentInfo> getArrearPaymentInfoList(int page, int row);
    
    /**
     * 根据姓名获取缴费信息
     * 
     * @param name
     * @return
     */
    List<PaymentInfo> getListByName(String name);
    
    /**
     * 根据姓名获取欠费的缴费信息
     * 
     * @param name
     * @return
     */
    List<PaymentInfo> getArrearListByName(String name);
    
    /**
     * 根据班级编号来获取缴费信息
     * @param classId
     * @return
     */
    List<PaymentInfo> getListByClassId(Long classId);
    
    /**
     * 根据班级编号来获取欠费的缴费信息
     * 
     * @param classId
     * @return
     */
    List<PaymentInfo> getArrearListByClassId(Long classId);
    
    /**
     * 根据专业编号来获取缴费信息
     * 
     * @param majorId
     * @return
     */
    List<PaymentInfo> getListByMajorId(Long majorId);
    
    /**
     * 根据专业编号来获取欠费的缴费信息
     * 
     * @param majorId
     * @return
     */
    List<PaymentInfo> getArrearListByMajorId(Long majorId);
    
    /**
     * 根据学年来获取缴费信息
     * 
     * @param schoolYear
     * @return
     */
    List<PaymentInfo> getListBySchoolYear(Integer schoolYear);
    
    /**
     * 根据学年来获取欠费的缴费信息
     * @param schoolYear
     * @return
     */
    List<PaymentInfo> getArrearListBySchoolYear(Integer schoolYear);
    
    /**
     * 根据职工编号来获取缴费信息
     * 
     * @param employeeId  该职工编号必须为辅导员的
     * @return
     */
    List<PaymentInfo> getListByEmployeeId(Long employeeId);
    
    /**
     * 根据职工编号来获取欠费的缴费信息
     * 
     * @param employeeId  该职工编号必须为辅导员的
     * @return
     */
    List<PaymentInfo> getArrearListByEmployeeId(Long employeeId);
    
    /**
     * 根据系部获取缴费信息
     * 
     * @param departmentName
     * @return
     */
    List<PaymentInfo> getListByDepartmentName(String departmentName);
    
    /**
     * 根据系部获取欠费的缴费信息
     * 
     * @param departmentName
     * @return
     */
    List<PaymentInfo> getArrearListByDepartmentName(String departmentName);
    
    /**
     * 添加支付信息
     * @param paymentInfo
     */
    void insert(PaymentInfo paymentInfo);
    
    /**
     * 批量添加缴费信息
     * @param list
     */
    void insertBatch(List<PaymentInfo> list);
    
    /**
     * 修改支付信息
     * @param paymentInfo
     */
    void update(PaymentInfo paymentInfo);
    
    /**
     * 修改支付信息并且记录缴费详情
     * 
     * @param paymentInfo
     * @param paymentDetail
     */
    void updateAndAddDetail(PaymentInfo paymentInfo, PaymentDetail paymentDetail);
    
    /**
     * 导出缴费信息
     * 
     * @param totalPage 页数
     * @param pageRow 一页的行数
     * @return
     */
    HSSFWorkbook exportPaymentInfo(int totalPage, int pageRow);
}
