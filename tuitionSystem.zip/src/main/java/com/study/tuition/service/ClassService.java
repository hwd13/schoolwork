package com.study.tuition.service;

import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.study.tuition.domain.ClassInfo;

public interface ClassService {
    /**
     * 通过班级id返回班级
     * @param classId
     * @return
     */
    ClassInfo getById(Long classId);
    
    /**
     * 返回班级总数目
     * 
     * @return
     */
    int getTotal();
    
    /**
     * 通过班级名称和入学年份获取班级信息
     * 
     * @param name
     * @return
     */
    ClassInfo getByNameAndEnrollmentYear(String name, Integer enrollmentYear);
    
    /**
     * 通过班级名称来获取班级信息
     * 
     * @param name
     * @return
     */
    List<ClassInfo> getlistByName(String name);
    
    /**
     * 根据页和行返回班级信息
     * 
     * @return
     */
    List<ClassInfo> getList(int page,int row);
    
    /**
     * 根据专业编号来获取班级信息
     * @param majorId
     * @return
     */
    List<ClassInfo> getListByMajorId(Long majorId);
    
    /**
     * 根据专业编号和入学年份来获取班级信息
     * @param majorId
     * @param enrollmentYear
     * @return
     */
    List<ClassInfo> getListByMajorIdAndYear(Long majorId, Integer enrollmentYear);
    
    /**
     * 根据职工编号来获取班级信息
     * 
     * @param employeeId 该职工编号只能为辅导员
     * @return
     */
    List<ClassInfo> getListByEmployeeId(Long employeeId);
    
    /**
     * 添加班级
     * @param classInfo
     */
    void insert(ClassInfo classInfo);
    
    /**
     * 修改班级信息
     * @param classInfo
     */
    void update(ClassInfo classInfo);
    
    /**
     * 导出班级缴费情况表
     * @param totalPage
     * @param pageRow
     * @return
     */
    HSSFWorkbook exportPaymentInfo(int totalPage, int pageRow);
    
    /**
     * 导出班级欠费情况表
     * @param totalPage
     * @param pageRow
     * @return
     */
    HSSFWorkbook exportArrearClassInfo(int totalPage, int pageRow);
    
    /**
     * 导出班级人数
     * @param totalPage
     * @param pageRow
     * @return
     */
    HSSFWorkbook exportStudentCount(int totalPage, int pageRow);
}
