package com.study.tuition.util;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

public class ExcelUtil {
    private int row = 50; // 默认一页50行

    /**
     * 总页数
     * 
     * @param total
     * @return
     */
    public int getTotalPage(int total) {
        return total % row == 0 ? total / row : total / row + 1;
    }

    /**
     * 导出到前端
     * 
     * @param response
     * @param workbook
     *            工作簿
     * @param filename
     *            工作簿名称
     * @throws IOException
     */
    public void export(HttpServletResponse response, HSSFWorkbook workbook, String filename) throws IOException {
        response.reset();
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-disposition",
                "attachment;filename=" + URLEncoder.encode(filename, "UTF-8") + ".xls");
        OutputStream out = response.getOutputStream();
        workbook.write(out);
        out.flush();
        out.close();
    }

    /**
     * 
     * @param cell
     *            一个单元格的对象
     * @return 返回该单元格相应的类型的值
     */
    public static Object getRightTypeCell(Cell cell) {

        Object object = null;
        switch (cell.getCellType()) {
        case Cell.CELL_TYPE_STRING: {
            object = cell.getStringCellValue();
            break;
        }
        case Cell.CELL_TYPE_NUMERIC: {
            cell.setCellType(Cell.CELL_TYPE_NUMERIC);
            object = cell.getNumericCellValue();
            break;
        }

        case Cell.CELL_TYPE_FORMULA: {
            cell.setCellType(Cell.CELL_TYPE_NUMERIC);
            object = cell.getNumericCellValue();
            break;
        }

        case Cell.CELL_TYPE_BLANK: {
            cell.setCellType(Cell.CELL_TYPE_BLANK);
            object = cell.getStringCellValue();
            break;
        }
        }
        return object;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

}
