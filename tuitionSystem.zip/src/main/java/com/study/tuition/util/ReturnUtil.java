package com.study.tuition.util;

import java.util.List;

public class ReturnUtil<T> {

    /**
     * 如果list为空返回null,否则返回第一个对象
     * 
     * @param list
     * @return
     */
    public static <T> T returnObject(List<T> list) {
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }
}
