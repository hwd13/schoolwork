package com.study.tuition.mvc;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.ResponseResult;

@RestController
public class ErrorController {

    @RequestMapping(value = "/notLogin", produces = "application/json")
    public ResponseResult<String> notLogin(HttpServletResponse response) {
        response.setStatus(500);
        return ResponseResult.inst("NO_LOGIN_ERR", "未登录", "");
    }
}
