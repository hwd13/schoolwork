package com.study.tuition.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.MenuInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.RoleInfo;
import com.study.tuition.service.MenuInfoService;
import com.study.tuition.service.RoleMenuService;
import com.study.tuition.service.RoleService;

@RestController
@RequestMapping("/role")
public class RoleController extends BaseController{
    
    @Autowired
    private RoleService roleService;
    @Autowired
    private RoleMenuService roleMenuService;
    @Autowired
    private MenuInfoService menuInfoService;
    
    @RequestMapping(value="/getRole",produces="application/json")
    public ResponseResult<List<RoleInfo>> getRole() {
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", roleService.getRoleList());
    }
    
    @RequestMapping(value="/list",produces="application/json")
    public ResponseResult<List<RoleInfo>> list() {
        List<RoleInfo> list = roleService.getRoleList();
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", list.size(), list);
    }
    
    @RequestMapping(value="/get", produces="application/json")
    public ResponseResult<RoleInfo> get(Long roleId) {
        RoleInfo roleInfo = roleService.getById(roleId);
        
        List<MenuInfo> menuList = menuInfoService.setCheckedMenuList(roleId);
        roleInfo.setMenuList(menuList);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", roleInfo);
    }
    
    @RequestMapping(value="/edit", produces="application/json")
    public ResponseResult<String> edit(Long roleId, String menuIdList) {
        List<Long> list = this.stringAsList(menuIdList);
        try {
            roleMenuService.updateRoleMenu(roleId, list);
        } catch (Exception e) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "编辑错误!", "");
        }
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", "");
    }
    
    @RequestMapping(value="/add", produces="application/json")
    public ResponseResult<String> add(String roleName, String menuIdList) {
        List<Long> list = this.stringAsList(menuIdList);        
        try {
            RoleInfo roleInfo = new RoleInfo();
            roleInfo.setName(roleName);
            roleService.insert(roleInfo, list);
            return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", "");
        } catch (Exception e) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "添加失败!", "");
        }
    }
    
    /**
     * 将数字字符串转换为list
     * 
     * @param strs
     * @return
     */
    private List<Long> stringAsList(String strs) {
        List<Long> list = new ArrayList<>();
        String[] split = strs.split(",");
        for (int i = 0; i < split.length; i++) {
            list.add(Long.parseLong(split[i]));
        }
        return list;
    }
}
