package com.study.tuition.mvc;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController extends BaseController{
    
    @Autowired
    private UserService userService;
    
    /**
     * 登录
     * 
     * @param userName
     * @param password
     * @return
     */
    @RequestMapping(value="/login",produces ="application/json")
    public ResponseResult<String> login(String userName, String password) {
        if (userName == null || password == null) {
            return ResponseResult.inst("ERROR", "账号或者密码不能为空", "");
        }
        boolean isLogin = userService.checkLogin(userName, password);
        if (isLogin) {
            UserInfo userInfo = userService.getByUserName(userName);
            this.setUserId(userInfo.getId().intValue());
            return ResponseResult.inst("SUCCESS", "", "");
        } else {
            return ResponseResult.inst("ERROR", "账号或者密码错误", "");
        }
    }
    
    /**
     * 获取用户信息
     * 
     * @param page 页
     * @param limit 行
     * @param searchEntity 搜索的实体类
     * @return
     */
    @RequestMapping("/getAllUser")
    public ResponseResult<List<UserInfo>> getAllUser(int page, int limit, SearchEntity searchEntity) {
        String name = searchEntity.getRealName();
        if (name != null) {
            List<UserInfo> list = userService.getByName(name);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        return ResponseResult.inst("0", "", userService.getTotal(), userService.getUserList(page, limit));
    }
    
    /**
     * 获取当前用户信息
     * @return
     */
    @RequestMapping(value="/getCurrentUser",produces = "application/json")
    public ResponseResult<UserInfo> getCurrentUser() {
        UserInfo userInfo = userService.getById(this.getUserId().longValue());
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", userInfo);
    }
    
    @RequestMapping("/addUser")
    public String addUser() {
        return null;
    }
    
    /**
     * 修改用户
     * 
     * @param userInfo
     * @return 
     */
    @RequestMapping(value="/modifyUser", produces="application/json")
    public ResponseResult<String> modifyUser(UserInfo userInfo) {
        userService.update(userInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "修改成功!", "");
    }
    
    /**
     * 修改密码
     * @param oldPwd
     * @param newPwd
     * @return
     */
    @RequestMapping(value="/updatePassword",produces="application/json")
    public ResponseResult<String> updatePassword(String oldPwd, String newPwd) {
        UserInfo userInfo = userService.getById(this.getUserId().longValue());
        boolean isRight = userService.checkPassowrd(userInfo, oldPwd);
        if (isRight) {
            userInfo.setPassword(newPwd);
            userService.update(userInfo);
            return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", "");
        } else {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "密码不正确!", "");
        }
    }
    
    /**
     * 管理员修改用户密码
     * @param userName
     * @param password
     * @return
     */
    @RequestMapping(value = "/resetPassword", produces = "application/json")
    public ResponseResult<String> resetPassword(String userName, String password) {
        UserInfo userInfo = userService.getByUserName(userName);
        userInfo.setPassword(password);
        userService.update(userInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", "");
    }
    
    /**
     * 退出登录
     * @param session
     * @return
     */
    @RequestMapping(value="/exit",produces = "application/json")
    public ResponseResult<String> exit(HttpSession session) {
        session.invalidate();
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", "");
    }
    
}
