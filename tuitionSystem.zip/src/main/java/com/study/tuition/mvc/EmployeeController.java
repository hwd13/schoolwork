package com.study.tuition.mvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.EmployeeInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController extends BaseController {

    @Autowired
    private EmployeeService employeeService;

    /**
     * 添加职工
     * 
     * @param employeeInfo
     * @param userInfo
     * @return 
     */
    @RequestMapping("/addEmployee")
    public ResponseResult<String> addEmployee(EmployeeInfo employeeInfo, UserInfo userInfo) {
        employeeInfo.setUserInfo(userInfo);
        employeeService.insert(employeeInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "添加成功!", "");
    }

    @RequestMapping("/modifyEmployee")
    public String modifyEmployee() {
        return null;
    }

    /**
     * 获取职工信息
     * 
     * @param page 页
     * @param limit 行
     * @param searchEntity 搜索的实体类
     * @return
     */
    @RequestMapping("/list")
    public ResponseResult<List<EmployeeInfo>> list(int page, int limit, SearchEntity searchEntity) {
        String name = searchEntity.getRealName();
        if (name != null) {
            List<EmployeeInfo> list = employeeService.getListByName(name);
            return ResponseResult.inst("0", "", list.size(), list);
        } else {
            return ResponseResult.inst("0", "", employeeService.getTotal(),employeeService.getEmployeeList(page, limit));
        }
    }
}
