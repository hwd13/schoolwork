package com.study.tuition.mvc;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;



/**
 * Base控制器
 * <P>File name : BaseController.java </P>
 * <P>Author : fangxiaowen </P> 
 * <P>Date : 2016年8月24日 </P>
 */
public class BaseController{

	@Autowired
	private HttpSession session;
	
	public static final String SESSION_KEY_USERID = "USER_ID";
	public static final String SESSION_KEY_USERINFO = "USER_INFO";
	public static final String SESSION_KEY_CHECK_CODE = "CHECK_CODE";
	public static final String SESSION_KEY_CHECK_CODE_LAST_SEND = "CHECK_CODE_LAST_SEND";
	public static final String CODE_SUCCESS = "1";
	public static final String CODE_ERROR = "0";
	
	protected void setSession(String key, Object value){
		session.setAttribute(key, value);
	}
	
	protected Object getSession(String key){
		return session.getAttribute(key);
	}	
	
	/**
	 * 从session中获取用户id
	 * @return
	 */
	public Integer getUserId(){
		Object obj = session.getAttribute(SESSION_KEY_USERID);
		if(obj != null){
			return (Integer)obj;
		}else{
			return null;
		}
	}
	
	protected void setUserId(Integer userId){
		session.setAttribute(SESSION_KEY_USERID, userId);
	}
	
	
	/**
	 * 判断是否登录
	 * @return
	 */
	public boolean isLogined(){
		return (getUserId()!=null);
	}
	
    /**
     * 分发数据到页面接收 BaseController.responseSendMsg()<BR>
     * BaseController.responseSendMsg()<BR>
     * <P>Author :  fangxiaowen </P>  
     * <P>Date : 2016年9月19日 </P>
     * @param response
     * @param strMsg
     */
	protected void responseSendMsg(HttpServletResponse response, String strMsg) {
		try {
			response.setContentType("application/json;charset=utf-8");
			response.setCharacterEncoding("utf-8");
			response.getWriter().write(strMsg);
			response.getWriter().flush();
			response.getWriter().close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
