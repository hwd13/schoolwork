package com.study.tuition.mvc;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.ChargeItem;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.service.ChargeItemService;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.PaymentInfoService;
import com.study.tuition.service.StudentService;
import com.study.tuition.service.UserService;

@RestController
@RequestMapping("/chargeItem")
public class ChargeItemController extends BaseController {
    
    @Autowired
    private ChargeItemService chargeItemService;
    @Autowired
    private MajorService majorService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private UserService userService;
    @Autowired
    private PaymentInfoService paymentInfoService;

    @RequestMapping("/getChargeItem")
    public ResponseResult<List<ChargeItem>> getChargeItem(int page, int limit) {
        return ResponseResult.inst("0", "", chargeItemService.getTotal(), chargeItemService.getChargeItemList(page, limit));
    }

    @RequestMapping(value = "/add", produces = "application/json")
    public ResponseResult<String> addChargeItem(ChargeItem chargeItem) {
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(chargeItem.getMajorName(), chargeItem.getEnrollmentYear());
        if (majorInfo == null) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "无此专业", "");
        }
        chargeItem.setMajorId(majorInfo.getId());
        chargeItemService.insert(chargeItem);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "添加成功!", "");
    }

    @RequestMapping("/getCurrentStudentChargeItem")
    public ResponseResult<List<ChargeItem>> getCurrentStudentChargeItem() {
        UserInfo userInfo = userService.getById(this.getUserId().longValue());
        List<StudentInfo> list = studentService.getListByName(userInfo.getName());
        List<ChargeItem> chargeItem = new ArrayList<>();
        for (StudentInfo student : list) {
            if (student.getUserInfo().equals(userInfo)) {
                chargeItem = chargeItemService.getChargeItemByStudent(student);
                break;
            }
        }
        return ResponseResult.inst("0", "", chargeItem);
    }
    
    @RequestMapping(value="/updatePaymentInfo", produces = "application/json")
    public ResponseResult<String> updatePaymentInfo() {
        if (!this.enableUpdate()) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "不在时间段", "");
        }
        
        List<StudentInfo> studentList = studentService.getReadingList();
        PaymentInfo paymentInfo = null;
        for (StudentInfo student : studentList) {
            if (!student.getStatus().equals("在读")) {
                continue;
            }
            paymentInfo = chargeItemService.createPaymentInfo(student);
            paymentInfoService.insert(paymentInfo);
        }
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "操作成功", "");
    }
    
    /**
     * 判断财务管理员是否能够更新缴费信息(定死了只能在(08/01--08/20)之间能更新)
     * 
     * @return
     */
    private boolean enableUpdate() {
        LocalDate now = LocalDate.now();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();
        if (month != 8) {
            return false;
        } else {
            return day < 20 ? true : false;
        }
    }
}
