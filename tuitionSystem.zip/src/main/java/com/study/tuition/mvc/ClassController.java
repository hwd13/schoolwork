package com.study.tuition.mvc;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.EmployeeInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.EmployeeService;
import com.study.tuition.service.MajorService;
import com.study.tuition.util.ExcelUtil;

@RestController
@RequestMapping("/class")
public class ClassController extends BaseController {

    @Autowired
    private ClassService classService;
    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private MajorService majorService;

    /**
     * 获取班级信息
     * 
     * @param page
     *            页
     * @param limit
     *            行
     * @param searchEntity
     *            搜索的实体类
     * @return
     */
    @RequestMapping("/list")
    public ResponseResult<List<ClassInfo>> list(int page, int limit, SearchEntity searchEntity) {
        if (!searchEntity.isEmpty()) {
            List<ClassInfo> list = this.search(searchEntity);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        return ResponseResult.inst("0", "", classService.getTotal(), classService.getList(page, limit));
    }

    @RequestMapping("/exportStudentCountExcel")
    public void exportStudentCountExcel(HttpServletResponse response) throws FileNotFoundException, IOException {
        ExcelUtil excel = new ExcelUtil();
        
        int total = classService.getTotal();
        int totalPage = excel.getTotalPage(total);
        
        HSSFWorkbook workbook = classService.exportStudentCount(totalPage, excel.getRow());
        excel.export(response, workbook, "学生信息统计表");
    }
    
    @RequestMapping("/exportPaymentInfoExcel")
    public void exportPaymentInfoExcel(HttpServletResponse response) throws FileNotFoundException, IOException {
        ExcelUtil excel = new ExcelUtil();
        
        int total = classService.getTotal();
        int totalPage = excel.getTotalPage(total);
        
        HSSFWorkbook workbook = classService.exportPaymentInfo(totalPage, excel.getRow());
        excel.export(response, workbook, "缴费情况统计表");
    }
    
    @RequestMapping("/exportArrearInfoExcel")
    public void exportArrearInfoExcel(HttpServletResponse response) throws FileNotFoundException, IOException {
        ExcelUtil excel = new ExcelUtil();
        
        int total = classService.getTotal();
        int totalPage = excel.getTotalPage(total);
        
        HSSFWorkbook workbook = classService.exportArrearClassInfo(totalPage, excel.getRow());
        excel.export(response, workbook, "欠费情况统计表");
    }
    
    /**
     * 添加班级
     * 
     * @param classInfo
     * @return
     */
    @RequestMapping(value = "/addClass", produces = "application/json")
    public ResponseResult<String> addClass(ClassInfo classInfo) {
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(classInfo.getMajorName(),
                classInfo.getEnrollmentYear());
        if (majorInfo == null) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "无此专业", "");
        }
        List<EmployeeInfo> list = employeeService.getListByName(classInfo.getEmployeeName());
        if (list.isEmpty()) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "无此辅导员", "");
        }
        for (EmployeeInfo employeeInfo : list) {
            if (employeeInfo.getDepartmentName().equals("督导组")) {
                classInfo.setEmployeeId(employeeInfo.getId());
                break;
            }
        }
        classInfo.setMajorId(majorInfo.getId());

        classService.insert(classInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "添加成功", "");
    }

    /**
     * 搜索 
     * 如果班级名称不为空则根据班级名称查询班级，如果得到的数据为空则直接返回空数据给前端,以此类推
     * 
     * @param searchEntity
     * @return
     */
    private List<ClassInfo> search(SearchEntity searchEntity) {
        List<ClassInfo> list = new ArrayList<>();
        Integer enrollmentYear = searchEntity.getEnrollmentYear();

        String className = searchEntity.getClassName();
        if (className != null) {
            list = this.searchByClassNameAndYear(list, className, enrollmentYear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String majorName = searchEntity.getMajorName();
        if (majorName != null) {
            list = this.searchByMajorNameAndYear(list, majorName, enrollmentYear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String employeeName = searchEntity.getEmployeeName();
        if (employeeName != null) {
            list = this.searchByEmployeeName(list, employeeName);
            if (list.isEmpty()) {
                return list;
            }
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份搜索班级(如果className不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     *            不为空则取交集
     * @param className
     * @param enrollmentYear
     * @return
     */
    private List<ClassInfo> searchByClassNameAndYear(List<ClassInfo> list, String className, Integer enrollmentYear) {
        if (className != null) {
            if (enrollmentYear != null) {
                list = this.searchByClassNameExistYear(list, className, enrollmentYear);
            } else {
                list = this.searchByClassNameNotExistYear(list, className);
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取班级信息 (如果majorName不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     *            如果list不为空，取交集
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<ClassInfo> searchByMajorNameAndYear(List<ClassInfo> list, String majorName, Integer enrollmentYear) {
        if (majorName == null) {
            return list;
        }
        if (enrollmentYear != null) {
            list = this.searchByMajorNameExistYear(list, majorName, enrollmentYear);
        } else {
            list = this.searchByMajorNameNotExistYear(list, majorName);
        }
        return list;
    }

    /**
     * 根据辅导员姓名来获取班级信息 (如果employeeName不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     *            不为空则取交集
     * @param employeeName
     * @return
     */
    private List<ClassInfo> searchByEmployeeName(List<ClassInfo> list, String employeeName) {
        if (employeeName == null) {
            return list;
        }
        List<EmployeeInfo> employeeList = employeeService.getListByName(employeeName);
        if (employeeList.isEmpty()) {
            list.clear();
            return list;
        }
        // 如果list 不为空，取交集
        if (list.isEmpty()) {
            for (EmployeeInfo employeeInfo : employeeList) {
                list.addAll(classService.getListByEmployeeId(employeeInfo.getId()));
            }
        } else {
            for (EmployeeInfo employeeInfo : employeeList) {
                list.retainAll(classService.getListByEmployeeId(employeeInfo.getId()));
            }
        }
        return list;
    }

    /**
     * 根据班级名称获取班级信息
     * 
     * @param list
     * @param className
     * @return
     */
    private List<ClassInfo> searchByClassNameNotExistYear(List<ClassInfo> list, String className) {
        if (className == null) {
            return list;
        }
        List<ClassInfo> nameList = classService.getlistByName(className);
        // list 不为空则取交集
        if (list.isEmpty()) {
            list.addAll(nameList);
        } else {
            list.retainAll(nameList);
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份获取班级信息
     * 
     * @param list
     * @param className
     * @param enrollmentYear
     * @return
     */
    private List<ClassInfo> searchByClassNameExistYear(List<ClassInfo> list, String className, Integer enrollmentYear) {
        if (className == null || enrollmentYear == null) {
            return list;
        }
        ClassInfo classInfo = classService.getByNameAndEnrollmentYear(className, enrollmentYear);
        if (classInfo != null) {
            // list 为空则添加，不为空则判断是否已经存在此数据，不存在则清空list
            if (list.isEmpty()) {
                list.add(classInfo);
            } else {
                boolean isExist = list.contains(classInfo);
                if (!isExist) {
                    list.clear();
                }
            }
        } else {
            list.clear();
        }
        return list;
    }

    /**
     * 根据专业名称获取班级信息
     * 
     * @param list
     * @param majorName
     * @return
     */
    private List<ClassInfo> searchByMajorNameNotExistYear(List<ClassInfo> list, String majorName) {
        if (majorName == null) {
            return list;
        }
        List<MajorInfo> majorList = majorService.getListByName(majorName);
        if (majorList.isEmpty()) {
            list.clear();
            return list;
        }
        // 如果list 不为空，取交集
        if (list.isEmpty()) {
            for (MajorInfo majorInfo : majorList) {
                list.addAll(classService.getListByMajorId(majorInfo.getId()));
            }
        } else {
            for (MajorInfo majorInfo : majorList) {
                list.retainAll(classService.getListByMajorId(majorInfo.getId()));
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取班级信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<ClassInfo> searchByMajorNameExistYear(List<ClassInfo> list, String majorName, Integer enrollmentYear) {
        if (majorName == null || enrollmentYear == null) {
            return list;
        }
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(majorName, enrollmentYear);
        if (majorInfo != null) {
            List<ClassInfo> mojorNameList = classService.getListByMajorIdAndYear(majorInfo.getId(), enrollmentYear);
            // 如果list不为空，取交集
            if (list.isEmpty()) {
                list.addAll(mojorNameList);
            } else {
                list.retainAll(mojorNameList);
            }
        } else {
            list.clear();
        }
        return list;
    }
}
