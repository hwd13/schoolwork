package com.study.tuition.mvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.service.MajorService;

@RestController
@RequestMapping("/major")
public class MajorController extends BaseController {

    @Autowired
    private MajorService majorService;

    /**
     * 获取专业信息 如果专业名称不为空则根据专业名称查询专业，如果得到的数据为空则直接返回空数据给前端,以此类推
     * 
     * @param page
     *            页
     * @param limit
     *            行
     * @param searchEntity
     *            搜索实体类
     * @return
     */
    @RequestMapping("/list")
    public ResponseResult<List<MajorInfo>> list(int page, int limit, SearchEntity searchEntity) {
        if (!searchEntity.isEmpty()) {
            List<MajorInfo> list = this.search(searchEntity);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        return ResponseResult.inst("0", "", majorService.getTotal(), majorService.getMajorList(page, limit));
    }

    /**
     * 添加专业
     * 
     * @param majorInfo
     * @return
     */
    @RequestMapping("/addMajor")
    public ResponseResult<String> addMajor(MajorInfo majorInfo) {
        majorService.insert(majorInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "添加成功!", "");
    }

    /**
     * 搜索 如果专业名称不为空则根据专业名称查询专业信息，如果得到的数据为空则直接返回空数据给前端,以此类推
     * 
     * @param searchEntity
     * @return
     */
    private List<MajorInfo> search(SearchEntity searchEntity) {
        List<MajorInfo> list = new ArrayList<>();
        Integer enrollmentYear = searchEntity.getEnrollmentYear();

        String majorName = searchEntity.getMajorName();
        if (majorName != null) {
            list = this.searchByMajorNameAndYear(list, majorName, enrollmentYear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String departmentName = searchEntity.getDepartmentName();
        if (departmentName != null) {
            list = this.searchByDepartmentName(list, departmentName);
            if (list.isEmpty()) {
                return list;
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取专业信息(如果majorName不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     *            不为空则取交集
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<MajorInfo> searchByMajorNameAndYear(List<MajorInfo> list, String majorName, Integer enrollmentYear) {
        if (majorName == null) {
            return list;
        }
        if (enrollmentYear != null) {
            list = this.searchByMajorNameExistYear(list, majorName, enrollmentYear);
        } else {
            list = this.searchByMajorNameNotExistYear(list, majorName);
        }
        return list;
    }

    /**
     * 根据系部名称获取专业信息(如果departmentName不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     *            不为空则去交集
     * @param departmentName
     * @return
     */
    private List<MajorInfo> searchByDepartmentName(List<MajorInfo> list, String departmentName) {
        if (departmentName == null) {
            return list;
        }
        List<MajorInfo> majorList = majorService.getListByDepartmentName(departmentName);
        if (list.isEmpty()) {
            list.addAll(majorList);
        } else {
            list.retainAll(majorList);
        }
        return list;
    }

    /**
     * 根据专业名称获取专业信息
     * 
     * @param list
     * @param majorName
     * @return
     */
    private List<MajorInfo> searchByMajorNameNotExistYear(List<MajorInfo> list, String majorName) {
        if (majorName == null) {
            return list;
        }
        List<MajorInfo> nameList = majorService.getListByName(majorName);
        // list 不为空则取交集
        if (list.isEmpty()) {
            list.addAll(nameList);
        } else {
            list.retainAll(nameList);
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取专业信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<MajorInfo> searchByMajorNameExistYear(List<MajorInfo> list, String majorName, Integer enrollmentYear) {
        if (majorName == null || enrollmentYear == null) {
            return list;
        }
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(majorName, enrollmentYear);
        // majorInfo 为空则清空list
        if (majorInfo != null) {
            // list 为空则添加，不为空如果数据不存在则清空list
            if (list.isEmpty()) {
                list.add(majorInfo);
            } else {
                boolean isExist = list.contains(majorInfo);
                if (!isExist) {
                    list.clear();
                }
            }
        } else {
            list.clear();
        }
        return list;
    }
}
