package com.study.tuition.mvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.MenuInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.service.MenuInfoService;
import com.study.tuition.service.UserService;

@RestController
@RequestMapping("/menu")
public class MenuController extends BaseController {
    @Autowired
    private UserService userService;
    @Autowired
    private MenuInfoService menuInfoService;

    @RequestMapping(value = "/getMenu",produces = "application/json")
    public List<MenuInfo> getMenu() {
        UserInfo userInfo = userService.getById(this.getUserId().longValue());
        return menuInfoService.getMenuListByRoleId(userInfo.getRoleId());
    }
    
    @RequestMapping(value="/all", produces="application/json")
    public ResponseResult<List<MenuInfo>> all(Long roleId) {
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", menuInfoService.getMenuList());
    }
    
    @RequestMapping(value = "/getButton", produces = "application/json")
    public ResponseResult<List<MenuInfo>> getCurrentUserButton() {
        UserInfo userInfo = userService.getById(this.getUserId().longValue());
        List<MenuInfo> list = menuInfoService.getButtonByRoleId(userInfo.getRoleId());
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "", list);
    }
}
