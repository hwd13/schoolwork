package com.study.tuition.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class LoginInterceptor extends BaseController implements HandlerInterceptor {

    @Override
    public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
            throws Exception {
    }

    @Override
    public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
            throws Exception {
    }

    @Override
    public boolean preHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2) throws Exception {
        if (arg0.getRequestURI().equals("/tuitionSystem/user/login")
                || arg0.getRequestURI().equals("/tuitionSystem/notLogin")) {
            return true;
        } else {
            if (this.isLogined()) {
                return true;
            } else {
                arg1.sendRedirect("/tuitionSystem/notLogin");
                return false;
            }
        }
    }
}

class ResponseStatus {
    int status;
    String code;
    String msg;

    public ResponseStatus(int status, String code, String msg) {
        super();
        this.status = status;
        this.code = code;
        this.msg = msg;
    }

    public static ResponseStatus inst(int status, String code, String msg) {
        return new ResponseStatus(status, msg, msg);
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}