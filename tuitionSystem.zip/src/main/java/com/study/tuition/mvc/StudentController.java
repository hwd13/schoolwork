package com.study.tuition.mvc;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.domain.UserInfo;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.StudentService;
import com.study.tuition.util.ExcelUtil;

@RestController
@RequestMapping("/student")
public class StudentController extends BaseController {

    @Autowired
    private StudentService studentService;
    @Autowired
    private ClassService classService;
    @Autowired
    private MajorService majorService;

    @RequestMapping(value = "/addStudent", produces = "application/json")
    public ResponseResult<String> addStudent(UserInfo user, StudentInfo student, ClassInfo classInfo, String className,
            String studentStatus) {
        // 截取入学年份
        String enrollmentYearStr = student.getEnrollmentDate();
        Integer enrollmentYear = Integer.parseInt(enrollmentYearStr.substring(0, 4));
        // 获取班级信息
        classInfo = classService.getByNameAndEnrollmentYear(className, enrollmentYear);
        if (classInfo == null) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "该年级没有此班级", "");
        }
        student.setUserInfo(user);
        student.setClassId(classInfo.getId());
        student.setStatus(studentStatus);
        studentService.insert(student);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "提交成功", "");
    }

    /**
     * 获取学生信息
     * 
     * @param page
     *            页
     * @param limit
     *            行
     * @param searchEntity
     *            搜索实体类
     * @return
     */
    @RequestMapping("/list")
    public ResponseResult<List<StudentInfo>> list(int page, int limit, SearchEntity searchEntity) {
        if (!searchEntity.isEmpty()) {
            List<StudentInfo> list = this.search(searchEntity);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        return ResponseResult.inst("0", "", studentService.getTotal(), studentService.getStudentList(page, limit));
    }

    @RequestMapping("/importExcel")
    public ResponseResult<String> importExcel(MultipartFile file) throws IOException {
        InputStream inputStream = file.getInputStream();
        HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
        String msg = studentService.insertBatchByImport(workbook);
        if ("SUCCESS".equals(msg)) {
            return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "导入成功", "");
        } else {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, msg, "");
        }
    }

    @RequestMapping("/exportExcel")
    public void exportExcel(HttpServletResponse response) throws FileNotFoundException, IOException {
        ExcelUtil excel = new ExcelUtil();
        
        int total = studentService.getTotal();
        int totalPage = excel.getTotalPage(total);
        
        HSSFWorkbook workbook = studentService.exportStudent(totalPage, excel.getRow());
        excel.export(response, workbook, "学生信息表");
    }

    @RequestMapping("/modifyStudent")
    public String modifyStudent() {
        return null;
    }

    @RequestMapping("/deleteStudent")
    public String deleteStudent() {
        return null;
    }


    /**
     * 搜索 如果班级名称不为空则根据班级名称查询班级，如果得到的数据为空则直接返回空数据给前端,以此类推
     * 
     * @param searchEntity
     * @return
     */
    private List<StudentInfo> search(SearchEntity searchEntity) {
        List<StudentInfo> list = new ArrayList<>();
        Integer enrollmentYear = searchEntity.getEnrollmentYear();

        Long studentId = searchEntity.getStudentId();
        if (studentId != null) {
            list = this.searchByStudentId(list, studentId);
            if (list.isEmpty()) {
                return list;
            }
        }
        String realName = searchEntity.getRealName();
        if (realName != null) {
            list = this.searchByRealName(list, realName);
            if (list.isEmpty()) {
                return list;
            }
        }
        String className = searchEntity.getClassName();
        if (className != null) {
            list = this.searchByClassNameAndYear(list, className, enrollmentYear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String majorName = searchEntity.getMajorName();
        if (majorName != null) {
            list = this.searchByMarjoNameAndYear(list, majorName, enrollmentYear);
            if (list.isEmpty()) {
                return list;
            }
        }
        return list;
    }

    /**
     * 根据学号获取学生信息(如果studentId不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     * @param studentId
     * @return
     */
    private List<StudentInfo> searchByStudentId(List<StudentInfo> list, Long studentId) {
        if (studentId != null) {
            StudentInfo studentInfo = studentService.getById(studentId);
            if (list.isEmpty()) {
                list.add(studentInfo);
            }
        }
        return list;
    }

    /**
     * 根据学生姓名获取学生信息
     * 
     * @param list
     * @param realName
     * @return
     */
    private List<StudentInfo> searchByRealName(List<StudentInfo> list, String realName) {
        if (realName == null) {
            return list;
        }
        List<StudentInfo> studentList = studentService.getListByName(realName);
        if (list.isEmpty()) {
            list.addAll(studentList);
        } else {
            list.retainAll(studentList);
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份获取学生信息,分了是否存在入学年份的情况(如果className不等于空的list为空，则表示查询数据为空)
     * 
     * @param list
     * @param className
     * @param enrollmentYear
     * @return
     */
    private List<StudentInfo> searchByClassNameAndYear(List<StudentInfo> list, String className,
            Integer enrollmentYear) {
        if (className != null) {
            if (enrollmentYear != null) {
                list = this.searchByClassNameExistYear(list, className, enrollmentYear);
            } else {
                list = this.searchByClassNameNotExistYear(list, className);
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取学生信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<StudentInfo> searchByMarjoNameAndYear(List<StudentInfo> list, String majorName,
            Integer enrollmentYear) {
        if (majorName != null) {
            if (enrollmentYear != null) {
                list = this.searchByMajorNameExistYear(list, majorName, enrollmentYear);
            } else {
                list = this.searchByMajorNameNotExistYear(list, majorName);
            }
        }
        return list;
    }

    /**
     * 根据班级名称获取学生信息
     * 
     * @param list
     * @param className
     * @return
     */
    private List<StudentInfo> searchByClassNameNotExistYear(List<StudentInfo> list, String className) {
        if (className == null) {
            return list;
        }
        List<ClassInfo> classList = classService.getlistByName(className);
        if (classList.isEmpty()) {
            list.clear();
            return list;
        }
        // list 不为空则取交集
        if (list.isEmpty()) {
            for (ClassInfo classInfo : classList) {
                list.addAll(studentService.getListByClassId(classInfo.getId()));
            }
        } else {
            for (ClassInfo classInfo : classList) {
                list.retainAll(studentService.getListByClassId(classInfo.getId()));
            }
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份获取学生信息
     * 
     * @param list
     * @param className
     * @param enrollmentYear
     * @return
     */
    private List<StudentInfo> searchByClassNameExistYear(List<StudentInfo> list, String className,
            Integer enrollmentYear) {
        if (className == null || enrollmentYear == null) {
            return list;
        }
        ClassInfo classInfo = classService.getByNameAndEnrollmentYear(className, enrollmentYear);
        if (classInfo != null) {
            List<StudentInfo> studentList = studentService.getListByClassId(classInfo.getId());
            // list 不为空则取交集
            if (list.isEmpty()) {
                list.addAll(studentList);
            } else {
                list.retainAll(studentList);
            }
        } else {
            list.clear();
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取学生信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @return
     */
    private List<StudentInfo> searchByMajorNameExistYear(List<StudentInfo> list, String majorName,
            Integer enrollmentYear) {
        if (majorName == null || enrollmentYear == null) {
            return list;
        }
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(majorName, enrollmentYear);
        if (majorInfo != null) {
            List<StudentInfo> studentList = studentService.getListByMajorId(majorInfo.getId());
            if (list.isEmpty()) {
                list.addAll(studentList);
            } else {
                list.retainAll(studentList);
            }
        } else {
            list.clear();
        }
        return list;
    }

    /**
     * 根据专业名称获取学生信息
     * 
     * @param list
     * @param majorName
     * @return
     */
    private List<StudentInfo> searchByMajorNameNotExistYear(List<StudentInfo> list, String majorName) {
        if (majorName == null) {
            return list;
        }
        List<MajorInfo> majorList = majorService.getListByName(majorName);
        if (majorList.isEmpty()) {
            list.clear();
            return list;
        }
        if (list.isEmpty()) {
            for (MajorInfo majorInfo : majorList) {
                list.addAll(studentService.getListByMajorId(majorInfo.getId()));
            }
        } else {
            for (MajorInfo majorInfo : majorList) {
                list.retainAll(studentService.getListByMajorId(majorInfo.getId()));
            }
        }
        return list;
    }
}
