package com.study.tuition.mvc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.tuition.domain.ClassInfo;
import com.study.tuition.domain.MajorInfo;
import com.study.tuition.domain.PaymentDetail;
import com.study.tuition.domain.PaymentInfo;
import com.study.tuition.domain.ResponseResult;
import com.study.tuition.domain.SearchEntity;
import com.study.tuition.domain.StudentInfo;
import com.study.tuition.service.ClassService;
import com.study.tuition.service.MajorService;
import com.study.tuition.service.PaymentDetailService;
import com.study.tuition.service.PaymentInfoService;
import com.study.tuition.util.ExcelUtil;

@RestController
@RequestMapping("/payment")
public class PaymentInfoController extends BaseController {

    @Autowired
    private PaymentInfoService paymentInfoService;
    @Autowired
    private PaymentDetailService paymentDetailService;
    @Autowired
    private ClassService classService;
    @Autowired
    private MajorService majorService;

    /**
     * 获取缴费信息
     * 
     * @param page
     * @param limit
     * @param searchEntity
     * @return
     */
    @RequestMapping("/getInfoList")
    public ResponseResult<List<PaymentInfo>> getInfoList(int page, int limit, SearchEntity searchEntity) {
        if (!searchEntity.isEmpty()) {
            List<PaymentInfo> list = this.search(searchEntity, false);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        return ResponseResult.inst("0", "", paymentInfoService.getTotal(),
                paymentInfoService.getPaymentInfoList(page, limit));
    }

    /**
     * 获取欠费的缴费信息
     * 
     * @param page
     * @param limit
     * @param searchEntity
     * @return
     */
    @RequestMapping("/arrearList")
    public ResponseResult<List<PaymentInfo>> arrearList(int page, int limit, SearchEntity searchEntity) {
        if (!searchEntity.isEmpty()) {
            List<PaymentInfo> list = this.search(searchEntity, true);
            return ResponseResult.inst("0", "", list.size(), list);
        }
        List<PaymentInfo> list = paymentInfoService.getArrearPaymentInfoList(page, limit);
        return ResponseResult.inst("0", "", list.size(), list);
    }
    
    /**
     * 根据学号获取缴费细节(因为只有一个学生的缴费详情，再多也多不到哪里去，所以无分页)
     * 
     * @param studentInfo
     * @return
     */
    @RequestMapping("/getDetailList")
    public ResponseResult<List<PaymentDetail>> getDetailList(StudentInfo studentInfo) {
        return ResponseResult.inst("0", "", paymentDetailService.getListByStudentId(studentInfo.getId()));
    }

    /**
     * 修改学生分期次数
     * 
     * @param paymentInfo
     * @return
     */
    @RequestMapping(value = "/modifyHirePurChaseCount", produces = "application/json")
    public ResponseResult<String> modifyHirePurChaseCount(@RequestBody PaymentInfo paymentInfo) {
        if (paymentInfo.getHirePurchaseCount() < 1 || paymentInfo.getHirePurchaseCount() > 12) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "分期次数最多12个月", "");
        }
        paymentInfoService.update(paymentInfo);
        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "修改成功!", "");
    }

    /**
     * 学生缴费
     * 
     * @param paymentInfo
     * @return
     */
    @RequestMapping(value = "/payTuition", produces = "application/json")
    public ResponseResult<String> payTuition(@RequestBody PaymentInfo paymentInfo) {
        paymentInfo.setMoney(paymentInfo.getMoney() * 100);
        Integer money = paymentInfo.getMoney();
        if (paymentInfo.getArrear() < money) {
            return ResponseResult.inst(ResponseResult.CODE_ERROR, "缴费金额大于欠费金额", "");
        }
        paymentInfo.setArrear(paymentInfo.getArrear() - money);
        if (paymentInfo.getArrear() == 0) {
            paymentInfo.setPayStatus(true);
        }
        PaymentDetail paymentDetail = paymentDetailService.createPaymentDetail(paymentInfo);
        paymentInfoService.updateAndAddDetail(paymentInfo, paymentDetail);

        return ResponseResult.inst(ResponseResult.CODE_SUCCESS, "缴费成功!", "");
    }

    @RequestMapping("/exportExcel")
    public void exportExcel(HttpServletResponse response) throws IOException {
        ExcelUtil excelUtil = new ExcelUtil();
        int total = paymentInfoService.getTotal();
        int totalPage = excelUtil.getTotalPage(total);
        
        HSSFWorkbook workbook = paymentInfoService.exportPaymentInfo(totalPage, excelUtil.getRow());
        excelUtil.export(response, workbook, "缴费信息表");
    }
    
    /**
     * 根据前端数据搜索 如果学号不为空则根据学号查询缴费信息，如果得到的数据为空则直接返回空数据给前端,以此类推
     * 
     * @param searchEntity
     * @return
     */
    private List<PaymentInfo> search(SearchEntity searchEntity, boolean isQueryArrear) {
        List<PaymentInfo> list = new ArrayList<>();
        Integer enrollmentYear = searchEntity.getEnrollmentYear();

        Long studentId = searchEntity.getStudentId();
        if (studentId != null) {
            list = this.searchByStudentId(list, studentId, isQueryArrear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String realName = searchEntity.getRealName();
        if (realName != null) {
            list = this.searchByRealName(list, realName, isQueryArrear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String className = searchEntity.getClassName();
        if (className != null) {
            list = this.searchByClassNameAndYear(list, className, enrollmentYear, isQueryArrear);
            if (list.isEmpty()) {
                return list;
            }
        }
        String majorName = searchEntity.getMajorName();
        if (majorName != null) {
            list = this.searchByMajorNameAndYear(list, majorName, enrollmentYear, isQueryArrear);
            if (list.isEmpty()) {
                return list;
            }
        }
        return list;
    }

    /**
     * 根据学号获取缴费信息
     * 
     * @param list
     *            不为空则取交集
     * @param studentId
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByStudentId(List<PaymentInfo> list, Long studentId, boolean isQueryArrear) {
        if (studentId != null) {
            PaymentInfo paymentInfo = null;
            if (isQueryArrear) {
                paymentInfo = paymentInfoService.getArrearByStudentId(studentId);
            } else {
                paymentInfo = paymentInfoService.getByStudentId(studentId);
            }
            if (list.isEmpty()) {
                list.add(paymentInfo);
            } else {
                boolean isExist = list.contains(paymentInfo);
                if (!isExist) {
                    list.clear();
                }
            }
        }
        return list;
    }

    /**
     * 根据姓名获取缴费信息
     * 
     * @param list
     *            不为空则取交集
     * @param realName
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByRealName(List<PaymentInfo> list, String realName, boolean isQueryArrear) {
        if (realName != null) {
            List<PaymentInfo> nameList = null;
            if (isQueryArrear) {
                nameList = paymentInfoService.getArrearListByName(realName);
            } else {
                nameList = paymentInfoService.getListByName(realName);
            }
            if (list.isEmpty()) {
                list.addAll(nameList);
            } else {
                list.retainAll(nameList);
            }
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份获取缴费信息
     * 
     * @param list
     * @param className
     * @param enrollmentYear
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByClassNameAndYear(List<PaymentInfo> list, String className,
            Integer enrollmentYear, boolean isQueryArrear) {
        if (className != null) {
            if (enrollmentYear != null) {
                list = this.searchByClassNameExistYear(list, className, enrollmentYear, isQueryArrear);
            } else {
                list = this.searchByClassNameNotExistYear(list, className, isQueryArrear);
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取缴费信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByMajorNameAndYear(List<PaymentInfo> list, String majorName,
            Integer enrollmentYear, boolean isQueryArrear) {
        if (majorName != null) {
            if (enrollmentYear != null) {
                list = this.searchByMajorNameExistYear(list, majorName, enrollmentYear, isQueryArrear);
            } else {
                list = this.searchByMajorNameNotExistYear(list, majorName, isQueryArrear);
            }
        }
        return list;
    }

    /**
     * 根据班级名称和入学年份获取缴费信息
     * 
     * @param list
     * @param className
     * @param enrollmentYear
     * @return
     */
    private List<PaymentInfo> searchByClassNameExistYear(List<PaymentInfo> list, String className,
            Integer enrollmentYear, boolean isQueryArrear) {
        if (className == null || enrollmentYear == null) {
            return null;
        }
        ClassInfo classInfo = classService.getByNameAndEnrollmentYear(className, enrollmentYear);
        if (classInfo != null) {
            List<PaymentInfo> paymentInfoList = null;
            if (isQueryArrear) {
                paymentInfoList = paymentInfoService.getArrearListByClassId(classInfo.getId());
            } else {
                paymentInfoList = paymentInfoService.getListByClassId(classInfo.getId());
            }
            if (list.isEmpty()) {
                list.addAll(paymentInfoList);
            } else {
                list.retainAll(paymentInfoList);
            }
        } else {
            list.clear();
        }
        return list;
    }

    /**
     * 根据班级名称获取缴费信息
     * 
     * @param list
     * @param className
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByClassNameNotExistYear(List<PaymentInfo> list, String className, boolean isQueryArrear) {
        if (className == null) {
            return list;
        }
        List<ClassInfo> classList = classService.getlistByName(className);
        if (classList.isEmpty()) {
            list.clear();
            return list;
        }
        if (list.isEmpty()) {
            for (ClassInfo classInfo : classList) {
                if (isQueryArrear) {
                    list.addAll(paymentInfoService.getArrearListByClassId(classInfo.getId()));
                } else {
                    list.addAll(paymentInfoService.getListByClassId(classInfo.getId()));
                }
            }
        } else {
            for (ClassInfo classInfo : classList) {
                if (isQueryArrear) {
                    list.retainAll(paymentInfoService.getArrearListByClassId(classInfo.getId()));
                } else {
                    list.retainAll(paymentInfoService.getListByClassId(classInfo.getId()));
                }
            }
        }
        return list;
    }

    /**
     * 根据专业名称和入学年份获取缴费信息
     * 
     * @param list
     * @param majorName
     * @param enrollmentYear
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByMajorNameExistYear(List<PaymentInfo> list, String majorName,
            Integer enrollmentYear, boolean isQueryArrear) {
        if (majorName == null || enrollmentYear == null) {
            return list;
        }
        MajorInfo majorInfo = majorService.getMajorByNameAndYear(majorName, enrollmentYear);
        if (majorInfo != null) {
            List<PaymentInfo> paymentInfoList = null;
            if (isQueryArrear) {
                list = paymentInfoService.getArrearListByMajorId(majorInfo.getId());
            } else {
                list = paymentInfoService.getListByMajorId(majorInfo.getId());
            }
            if (list.isEmpty()) {
                list.addAll(paymentInfoList);
            } else {
                list.retainAll(paymentInfoList);
            }
        } else {
            list.clear();
        }
        return list;
    }

    /**
     * 根据专业名称获取缴费信息
     * 
     * @param list
     * @param majorName
     * @param isQueryArrear
     * @return
     */
    private List<PaymentInfo> searchByMajorNameNotExistYear(List<PaymentInfo> list, String majorName, boolean isQueryArrear) {
        if (majorName == null) {
            return list;
        }
        List<MajorInfo> majorList = majorService.getListByName(majorName);
        if (majorList.isEmpty()) {
            list.clear();
            return list;
        }
        if (list.isEmpty()) {
            for (MajorInfo majorInfo : majorList) {
                if (isQueryArrear) {
                    list.addAll(paymentInfoService.getArrearListByMajorId(majorInfo.getId()));
                } else {
                    list.addAll(paymentInfoService.getListByMajorId(majorInfo.getId()));
                }
            }
        } else {
            for (MajorInfo majorInfo : majorList) {
                if (isQueryArrear) {
                    list.retainAll(paymentInfoService.getArrearListByMajorId(majorInfo.getId()));
                } else {
                    list.retainAll(paymentInfoService.getListByMajorId(majorInfo.getId()));
                }
            }
        }
        return list;
    }
}
