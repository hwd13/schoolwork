package com.study.tuition.domain;


public class ResponseResult<T> {
	
	public static final String CODE_SUCCESS = "SUCCESS";
	public static final String CODE_ERROR = "ERROR";	
	
	private String code;
	
	private String msg;
	
	private int count;
	
	private T data;

	public ResponseResult(String code, String msg, T data) {
		this.code = code;
		this.msg = msg;
		this.data = data;
	}

	public ResponseResult(String code, String msg, int count, T data) {
        this.code = code;
        this.msg = msg;
        this.count = count;
        this.data = data;
    }

    public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public static <T> ResponseResult<T> inst(){
		return new ResponseResult<T>(CODE_SUCCESS, "SUCCESS", null);
	}
	
	public static <T> ResponseResult<T> inst(T data){
		return new ResponseResult<T>(CODE_SUCCESS, "SUCCESS", data);
	}
	
	public static <T> ResponseResult<T> inst(String code, String msg, T data){
		return new ResponseResult<T>(code, msg, data);
	}
	
	public static <T> ResponseResult<T> inst(String code, String msg, int count, T data){
        return new ResponseResult<T>(code, msg, count, data);
    }
}
