//分页插件；依赖jquery ,暂只支持一个页面单个分页查询， 如有多个分页查询组合页面，需要修改插件得到支持
var Grid = {
	//参数
	options: {
		pageNum: 1,
		pageSize: 10,
		totalPage: 0,
		currentPage: 5,
		columns: null,//title,value,func,orderBy
		precheckedRows: [],
		checkBoxEvent: null,
		headerShow: null,
		url: null,
		type: 'GET',
		async: true,
		params: {},
		totalAttribute: 'data.total',
		dataAttribute: 'data.list',
		checkBox: false,
		radio: false,
		showNumber: false,
		htmlId: null,
		usePage: true,
		usePageId: 'paged',
		datas: [],
		sorts: {},
		orderByCuse: [],
		requestBody: false
	},
	//加载grid
	load(htmlId) {

		var that = this;
		that.options.htmlId = htmlId;
		var url = that.options.url;
		var params = that.options.params;
		//
		var totalAttribute = that.options.totalAttribute;
		var dataAttribute = that.options.dataAttribute;
		var pageSize = that.options.pageSize;
		var pageNum = that.options.pageNum;
		if (that.options.usePage) {
			if (params) {
				params['pageSize'] = pageSize;
				params['pageNum'] = pageNum;
			} else {
				params = { 'pageSize': pageSize, 'pageNum': pageNum }
			}
		}
		$.ajax({
			url: url,
			type: that.options.type,
			contentType: that.options.requestBody ? 'application/json;charset=utf-8' : 'application/x-www-form-urlencoded',
			data: that.options.requestBody ? JSON.stringify(params) : params,
			async: that.options.async,
			success: function (result) {

				if (result) {
					if (that.options.usePage) {
						var totalArrs = totalAttribute.split('.');
						var total = result;
						//						console.log(total.data.total);
						var gettosl = total.data.total;
						$('#gettotal').attr('settal', gettosl);
						$('#agenttoal').attr('agentset', gettosl);
						var getallcout = $('#gettotal').attr('settal');
						var agentcout = $('#agenttoal').attr('agentset');
						$('#allCount').html(getallcout);
						$('#agentSum').html(agentcout);
						for (var i = 0; i < totalArrs.length; i++) {
							total = total[totalArrs[i]];
						}
						that.options.totalPage = Math.ceil(total / pageSize);
						that.loadPagePlugin();
					}
					var dataArrs = dataAttribute.split('.');
					var data = result;
					for (var i = 0; i < dataArrs.length; i++) {
						data = data[dataArrs[i]];
					}
					if (data) {
						for (var i = 0; i < data.length; i++) {
							data[i]['__index'] = i;
						}
					}
					that.options.datas = data;
					that.loadData(htmlId, data);
				}
			}
		});
	},
	//加载分页控件
	loadPagePlugin: function () {
		var that = this;
		var totalPage = that.options.totalPage == 0 ? 1 : that.options.totalPage;
		var currentPage = that.options.currentPage;
		var pageNum = that.options.pageNum;
		var preNum = pageNum > 1 ? pageNum - 1 : pageNum;
		var nextNum = pageNum < totalPage ? pageNum + 1 : pageNum;
		var start = pageNum - currentPage >= 1 ? pageNum - currentPage : 1;
		var end = pageNum + currentPage < totalPage ? pageNum + currentPage : totalPage;
		if (end - start < currentPage * 2) {
			end = start + currentPage * 2 <= totalPage ? start + currentPage * 2 : totalPage;
		}
		if (end - start < currentPage * 2) {
			start = end - currentPage * 2 >= 1 ? end - currentPage * 2 : 1;
		}
		var html = "<a href=\"javascript:Grid.goPage(1)\">首页</a>&nbsp;<a href=\"javascript:Grid.goPage(" + preNum + ")\">上一页</a>&nbsp;";
		if (start > 1) {
			html += "<a href=\"javascript:Grid.goPage(1)\">1</a>&nbsp;";
			if (start > 2) {
				html += "<a>...</a>&nbsp;";
			}
		}
		for (var i = start; i <= end; i++) {
			html += "<a href=\"javascript:Grid.goPage(" + i + ")\" " + (pageNum == i ? "style=\"background:rgb(0, 150, 136);color:#ffffff;\"" : "") + ">" + i + "</a>&nbsp;";
		}
		if (end < totalPage) {
			if (end < totalPage - 1) {
				html += '<a>...</a>&nbsp;';
			}
			html += "<a href=\"javascript:Grid.goPage(" + totalPage + ")\">" + totalPage + "</a>&nbsp;";
		}
		html += "<a href=\"javascript:Grid.goPage(" + nextNum + ")\">下一页</a>&nbsp;<a href=\"javascript:Grid.goPage(" + totalPage + ")\">尾页</a>&nbsp;";
		$('#' + that.options.usePageId).html(html);
	},
	//加载数据
	loadData: function (htmlId, datas) {
		var columns = this.options.columns;
		var checkBox = this.options.checkBox;
		var radio = this.options.radio;
		var showNumber = this.options.showNumber;
		var pageNum = this.options.pageNum;
		var pageSize = this.options.pageSize;
		var orderBy = this.options.orderBy;
		var sorts = this.options.sorts;
		var omit = this.options.omit;
		if (!columns || columns.length == 0) return;
		var html = '';
		if (this.options.headerShow) {
			var headHtml = this.options.headerShow(this.options.precheckedRows, datas);
			html += headHtml;
		}
		//构建table
		html += '<table class="layui-table admin-table">';
		//构建title
		html += '<thead>';
		if (radio) {
			html += '<th width="4%">&nbsp;</th>';
		}
		if (checkBox) {
			html += '<th width="4%"><input type="checkBox" onclick="Grid.selectAll(this)" class="selectAll" style="display:block;"></th>';
		}
		if (showNumber) {
			html += '<th width="5%">序号</th>';
		}
		for (var i = 0; i < columns.length; i++) {
			var orderByHtml = '';
			if (columns[i]["orderBy"]) {
				var imgSrc = '../../images/noneSort.png';
				if (sorts[columns[i]['orderBy']] == 'asc') {
					imgSrc = '../../images/asc.png';
				} else if (sorts[columns[i]['orderBy']] == 'desc') {
					imgSrc = '../../images/desc.png';
				}
				orderByHtml += "<img id=\"" + columns[i]['orderBy'] + "\" src=\"" + imgSrc + "\" style=\"margin-left:10px; width: 10px; height:13px;\" onclick=\"Grid.sort('" + columns[i]["orderBy"] + "');\"/>";
			}
			html += '<th>' + columns[i]["title"] + orderByHtml + '</th>';
		}
		html += '</thead>';

		//构建数据
		html += '<tbody>';
		if (datas) {
			for (var i = 0; i < datas.length; i++) {
				var obj = datas[i];
				html += '<tr>';
				if (radio) {
					var checked = false;
					$(Grid.options.precheckedRows).each(function (x, m) {
						if (obj[m['name']] == m['value'][m['name']]) {
							checked = true;
							return false;
						}
					});
					html += '<td><input type="radio" value="' + i + '" ' + (checked ? 'checked="checked"' : '') + ' class="_radio" name="_radio" style="display:block;"></td>';
				}
				if (checkBox) {
					var checked = false;
					$(Grid.options.precheckedRows).each(function (x, m) {
						if (obj[m['name']] == m['value'][m['name']]) {
							checked = true;
							return false;
						}
					});
					html += '<td><input type="checkBox" value="' + i + '" ' + (checked ? 'checked="checked"' : '') + ' class="_check_box" onclick="Grid.onChecked(this)" style="display:block;"></td>';
				}
				if (showNumber) {
					html += '<td>' + ((pageNum - 1) * pageSize + (i + 1)) + '</td>';
				}
				for (var j = 0; j < columns.length; j++) {
					var col = columns[j];
					var realValue = '';
					if (col['func'] && typeof (col['func']) == 'function') {
						realValue = (col['func'](obj) != '0' || col['func'](obj) ? col['func'](obj) : '');
					} else {
						realValue = (obj[col['value']] == '0' || obj[col['value']] ? obj[col['value']] : '');
					}
					if (omit) {
						if (realValue) {
							realValue = realValue.toString();
							if (realValue.indexOf("<") == -1 && realValue.length > 20) {
								var omitValue = realValue.substr(0, 20) + '...';
								html += "<td title='" + realValue + "'>" + omitValue + "</td>";
							} else {
								html += '<td>' + realValue + '</td>';
							}
						} else {
							html += '<td></td>';
						}
					} else {
						html += '<td>' + realValue + '</td>';
					}

				}
				html += '</tr>';
			}
		}
		html += '</tbody>';
		html += '</table>';

		$('#' + htmlId).html(html);
		$('.selectAll').prop('checked', $('._check_box:checked').length == datas.length);
		loadImg();//图片异步
	},
	//翻页
	goPage: function (pageNum) {
		this.getSelectedRows();
		var that = this;
		if (pageNum > that.options.totalPage || pageNum < 0) return;
		that.options.pageNum = pageNum;
		that.load(that.options.htmlId);
	},
	//排序
	sort: function (orderBy) {
		var that = this;
		var sorts = that.options.sorts;
		var imgSrc = $('#' + orderBy).attr('src');
		if (sorts[orderBy] == 'asc') {
			sorts[orderBy] = 'desc';
		} else {
			sorts[orderBy] = 'asc';
		}
		var orderByCuse = Grid.options.orderByCuse;
		if (orderByCuse && orderByCuse.length > 0) {
			var flag = false;
			$(orderByCuse).each(function (i, n) {
				if (n.indexOf(orderBy) >= 0) {
					orderByCuse.splice(i, 1);
					orderByCuse.splice(0, 0, orderBy + ' ' + sorts[orderBy]);
					flag = true;
					return false;
				}
			});
			if (!flag) {
				orderByCuse.splice(0, 0, orderBy + ' ' + sorts[orderBy]);
			}
			var orderByStr = '';
			$(orderByCuse).each(function (i, n) {
				orderByStr += n + ',';
			});
			if (orderByStr) {
				orderByStr = orderByStr.substring(0, orderByStr.length - 1);
				that.options.params['orderBy'] = orderByStr;
			}
		} else {
			that.options.params['orderBy'] = orderBy + ' ' + sorts[orderBy];
			orderByCuse.push(orderBy + ' ' + sorts[orderBy]);
		}
		that.load(that.options.htmlId);
	},
	//全选
	selectAll: function (o) {
		var that = this;
		var allIsChecked = $(o).is(':checked');
		var checkboxes = $('._check_box');
		allIsChecked ? checkboxes.prop('checked', true) : checkboxes.prop('checked', false);
		if (Grid.options.checkBoxEvent) {
			Grid.options.checkBoxEvent(that.options.datas, allIsChecked);
		}
	},
	//全选
	checkSelectAll: function () {
		var box = $('._check_box');
		var flag = true;
		$(box).each(function (i, n) {
			if (!$(n).is(':checked')) {
				flag = false;
				return false;
			}
		});
		if (flag) {
			$('.selectAll').prop('checked', true);
		} else {
			$('.selectAll').prop('checked', false);
		}
	},
	onChecked: function (o) {
		var that = this;
		var checked = $(o).is(':checked');
		var box = $('._check_box');
		var flag = true;
		$(box).each(function (i, n) {
			if (!$(n).is(':checked')) {
				flag = false;
				return false;
			}
		});
		if (flag) {
			$('.selectAll').prop('checked', true);
		} else {
			$('.selectAll').prop('checked', false);
		}
		if (Grid.options.checkBoxEvent) {
			var arr = [];
			arr.push(that.options.datas[o.value]);
			Grid.options.checkBoxEvent(arr, checked);
		}
	},
	//获取选中的行数据
	getSelectedRows: function () {
		var that = this;
		var arr = [];
		var selecteds = $('._check_box:checked');
		$.each(selecteds, function (i, n) {
			arr.push(that.options.datas[n.value]);
		});
		return arr;
	},
	//获取选中的行数据
	getRadioSelectedRow: function () {
		var that = this;
		var selected = $('._radio:checked')[0];
		return that.options.datas[selected.value];
	}
}
function searchParam() {
	var params = {};
	var className = $.trim($('#className').val());
	var enrollmentYear = $.trim($('#enrollmentYear').val());
	var majorName = $.trim($('#majorName').val());
	var employeeName = $.trim($('#employeeName').val());
	var realName = $.trim($('#realName').val());
	var studentId = $.trim($('#studentId').val());
	var departmentName = $.trim($('#departmentName').val());

	if (studentId) {
		params['studentId'] = studentId;
	}
	if (departmentName) {
		params['departmentName'] = departmentName;
	}
	if (realName) {
		params['realName'] = realName;
	}
	if (className) {
		params['className'] = className;
	}
	if (enrollmentYear) {
		params['enrollmentYear'] = enrollmentYear;
	}
	if (majorName) {
		params['majorName'] = majorName;
	}
	if (employeeName) {
		params['employeeName'] = employeeName;
	}
	return params;
}
