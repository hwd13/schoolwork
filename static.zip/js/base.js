urlConfig = {"serverBaseUrl":"http://127.0.0.1:8080/","frontBaseUrl":"http://127.0.0.1:8080/static/pages/","title":"学费管理系统1.0"}
var serverBaseUrl = urlConfig.serverBaseUrl;
var frontBaseUrl = urlConfig.frontBaseUrl;
var webTitel = urlConfig.title;
var ENV = urlConfig.env
$.ajaxSetup({
    xhrFields: {
        withCredentials: true
    },
    crossDomain: true
});

//获取url参数
function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}

Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1,                 //月份
        "d+": this.getDate(),                    //日
        "h+": this.getHours(),                   //小时
        "m+": this.getMinutes(),                 //分
        "s+": this.getSeconds(),                 //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds()             //毫秒
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

/**
 * 统一处理ajax 异常
 */
$(function () {
    //.ajaxError事件定位到document对象，文档内所有元素发生ajax请求异常，都将冒泡到document对象的ajaxError事件执行处理
    $(document).ajaxError(
        //所有ajax请求异常的统一处理函数，处理
        function (event, xhr, options, exc) {
            if (xhr.status == 'undefined') {
                return;
            }
            switch (xhr.status) {
                case 400:
                    // 参数转换错误
                    zdalert('提示', "输入有误");
                    break;
                case 403:
                    // 未授权异常
                    zdalert('提示', "系统拒绝：您没有访问权限");
                    break;

                case 404:
                    zdalert('提示', "您访问的资源不存在");
                    break;
                case 500:
                    // 系统异常
                    if (!$.alerts.isShow) {
                        if (xhr.responseJSON.code == 'NO_LOGIN_ERR') {
                            if (parent) {
                                parent.window.location.href = frontBaseUrl + 'login.html';
                            } else {
                                window.location.href = frontBaseUrl + 'login.html';
                            }
                        } else {
                            zdalert('提示', xhr.responseJSON.msg);
                        }

                    }
                    break;
                case 600:
                    // 系统异常
                    zdalert('提示', xhr.responseJSON.msg);
                    break;
                default:
                    break;
            }
        }
    );

});

function validateNum(num) {
    var reg = /^[1-9]\d*$/;
    return reg.test(num);
}

function uploadImage(upimg, urlid, sizeId, imgShowId) {
    var formData = new FormData();
    if (document.getElementById(upimg).files.length <= 0) {
        zdalert('提示', '未选择图片!');
        return false;
    }
    formData.append("file", document.getElementById(upimg).files[0]);
    var url = serverBaseUrl + 'manager/aliSts/upload';
    $.ajax({
        url: url,
        type: "POST",
        data: formData,
        /**
         *必须false才会自动加上正确的Content-Type
         */
        contentType: false,
        /**
         * 必须false才会避开jQuery对 formdata 的默认处理
         * XMLHttpRequest会对 formdata 进行正确的处理
         */
        processData: false,
        success: function (result) {
            if (result.code == "SUCCESS") {
                $('#' + urlid).val(result.data.url);
                if (imgShowId) {
                    $('#' + imgShowId).attr('src', result.data.url);
                }
                if (sizeId) {
                    $('#' + sizeId).val(result.data.size);
                }
                zdalert('提示', '上传成功!');
            }
        },
        error: function () {
            zdalert('提示', '上传失败!');
        }
    });
}

/**
 * desc 提示语说明
 * required 非空
 * lessLen 小于长度
 * moreLen 大于长度
 * isNum 校验数字
 * @param form
 * @returns
 */
function validateForm(form) {
    var result = true;
    //判断input标签
    $('#' + form).find("input[type='text']").each(function () {
        var current = jQuery.trim(jQuery(this).val());
        var desc = jQuery(this).attr('desc');
        if (jQuery(this)[0].hasAttribute('required')) {
            if (!current || current.length <= 0) {
                result = false;
                zdalert('提示', desc + '不能为空!');
                return false;
            }
        }
        if (jQuery(this)[0].hasAttribute('lessLen')) {
            var lessLen = jQuery(this).attr('lessLen');
            if (current.length > lessLen) {
                result = false;
                zdalert('提示', desc + '长度不能超过' + lessLen);
                return false;
            }
        }
        if (jQuery(this)[0].hasAttribute('moreLen')) {
            var moreLen = jQuery(this).attr('moreLen');
            if (current.length < moreLen) {
                result = false;
                zdalert('提示', desc + '长度不能小于' + moreLen);
                return false;
            }
        }
        if (jQuery(this)[0].hasAttribute('isNum')) {
            if (current && current.length > 0) {
                if (!validateNum(current)) {
                    result = false;
                    zdalert('提示', desc + '只能输入数字');
                    return false;
                }
            }
        }
    });
    //判断select标签
    $('#' + form).find("select").each(function () {
        var current = jQuery.trim(jQuery(this).val());
        var desc = jQuery(this).attr('desc');
        if (jQuery(this)[0].hasAttribute('required')) {
            if (!current || current.length <= 0) {
                result = false;
                zdalert('提示', desc + '不能为空!');
                return false;
            }
        }
    });
    //判断textarea标签
    $('#' + form).find("textarea").each(function () {
        var current = jQuery.trim(jQuery(this).val());
        var desc = jQuery(this).attr('desc');
        if (jQuery(this)[0].hasAttribute('required')) {
            if (!current || current.length <= 0) {
                result = false;
                zdalert('提示', desc + '不能为空!');
                return false;
            }
        }
        if (jQuery(this)[0].hasAttribute('lessLen')) {
            var lessLen = jQuery(this).attr('lessLen');
            if (current.length > lessLen) {
                result = false;
                zdalert('提示', desc + '长度不能超过' + lessLen);
                return false;
            }
        }
        if (jQuery(this)[0].hasAttribute('moreLen')) {
            var moreLen = jQuery(this).attr('moreLen');
            if (current.length < moreLen) {
                result = false;
                zdalert('提示', desc + '长度不能小于' + moreLen);
                return false;
            }
        }
    });
    return result;
}

//制保留4位小数，如：4，会在4后面补上00.即4.0000
function toDecimal4(x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return false;
    }
    var f = Math.round(x * 10000) / 10000;
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
        rs = s.length;
        s += '.';
    }
    while (s.length <= rs + 4) {
        s += '0';
    }
    return s;
}

function loadImg() {
    //图片异步加载
    var imgs = document.getElementsByTagName("img");
    for (var i = 0, l = imgs.length; i < l; i++) {
        var url = imgs[i].getAttribute("data-src");
        if (!imgs[i].src && url) {
            imgs[i].src = url;
        }
    }
}
