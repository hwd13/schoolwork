/**
 * 首页js
 */
(function() {
	var Index = function() {
		this.init();
	};
	Index.prototype = {
		//配置信息
		config : {
			gamesMap: parent.gamesMap,
            testMap: parent.gamesSelectMap,
			getIndexDataUrl:serverBaseUrl + 'manager/index',
			flag:true,
			chart:{}
		},
		//初始化方法
		init:function(){
			this.loadIndexData();

		},
		//加载分页数据
		loadIndexData:function(){			
			var url = this.config.getIndexDataUrl;
			$.ajax({
				url:url,
				success:function(result){
					if(result.code=='SUCCESS'){
						var data = result.data;
						
					}else{
						zdalert('提示',result.msg);
					}
				}
			});
		},
		
	};
	
	$(function() {
        //var k = 0;
        window.index = new Index();

	});
})();
