/**
 * 修改密码js
 */
(function() {
	var Password = function() {
		this.init();
	};
	
	Password.prototype = {
		
		//配置信息
		config : {
			// loadUpdatePwdUrl:serverBaseUrl + 'manager/login/updatePwd'	  //修改密码
			loadUpdatePwdUrl:'/tuitionSystem/user/updatePassword'	  //修改密码
		},
		
		//初始化方法
		init:function(){
//			this.loadUpdatePwd();
		},
		//修改密码
		loadUpdatePwd:function(){
			var url = this.config.loadUpdatePwdUrl;	
			var oldPwd = $('#oldPwd').val();
			var newPwd = $('#newPwd').val();
			var surePassword=$('#surePassword').val();
			var pwdReg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;//6到16位数字与字母组合
			if(oldPwd=='' || newPwd=='' || surePassword == ''){
				zdalert('提示','密码不能为空');
				return false;
			}
			// if(!pwdReg.test(oldPwd)|| !pwdReg.test(newPwd)){
			// 	zdalert('提示','请输入6到16位的数字与字母组合');
			// 	return false;
			// }
			if(newPwd != surePassword){
				zdalert('提示','两次密码输入不正确');
				return false;
			}
			$.ajax({
				url:url,
				type:'POST',
				data:{
					'oldPwd':oldPwd,
					'newPwd':newPwd
				},
				success:function(result){
					if(result.code=='SUCCESS'){
						zdalert('提示','操作成功',function(){
						window.history.go(-1);
						// window.location.href="index-password.html";
					});
				}else{
					zdalert('提示',result.msg);
					}
				}
			});
		}	
	};
	
	$(function() {
		window.password = new Password();
		$('#agentname').val(name).attr('disabled','true');
		$('#surebtn').click(function(){
			window.password.loadUpdatePwd();
		})
	});
})();
