/**
 * 用户管理 用户添加、编辑js
 */
(function() {
	
	var UserEdit = function() {
		this.init();
	};
	
	UserEdit.prototype = {
		
		//配置信息
		config : {
			getUserInfoByUserIdUrl:serverBaseUrl + 'manager/system/sysUser/user/get',
			editUserUrl:serverBaseUrl + 'manager/system/sysUser/user/edit',
			addUserUrl:serverBaseUrl + 'manager/system/sysUser/user/add',
			getRolesUrl:serverBaseUrl + 'manager/system/sysUser/role/list'
		},
		
		//初始化方法
		init:function(){
			this.loadUserInfo();
			this.initAjaxForm();
		},
		
		//初始化ajaxForm
		initAjaxForm:function(){
			var url = this.config.addUserUrl;
			var userId = getUrlParam('id');
			var pageTitle = '添加用户';
			if(userId){
				pageTitle = '编辑用户';
				url = this.config.editUserUrl;
			}
			$('#pageTitle').html(pageTitle);
			var options = {
					url:url,
					type:'POST',
					success:function(data){
						if(data.code=='SUCCESS'){
							zdalert('提示','操作成功',function(){
								window.history.go(-1);
							});
						}else{
							zdalert('提示',data.msg);
						}
					}
			};
			$("#form").ajaxForm(options);
		},
		
		//加载用户数据
		loadUserInfo:function(){
			return ;
			var userId = getUrlParam('id');
			if(userId){
				var url = this.config.getUserInfoByUserIdUrl;
				$.ajax({
					url:url,
					type:'POST',
					data:{userId:userId},
					success:function(result){
						if(result.code=='SUCCESS'){
							var data = result.data;
							$("input[name='userId']").val(data.userId);
							$("input[name='userName']").val(data.userName);
							$("input[name='userName']").attr("disabled",true);
							$("input[name='realName']").val(data.realName);
							$("input[name='idNumber']").val(data.idNumber);
							$("input[name='mobile']").val(data.mobile);
							$("select[name='type']").val(data.type);
							$("input[name='agentsId']").val(data.agentsId);
							$("select[name='status']").val(data.status);
							var pcRolesHtml = '<h6>PC端角色</h6><ul>';
							var wxRolesHtml = '<h6>微信端角色</h6><ul>';
							if($("select[name='type']").val()=='1'){
								$('#userhide').show();
							}else{
								$('#userhide').hide();
							}
							$.each(data.managerRoleVoList,function(i,n){
								if(n.sysType==1){//pc端角色
									pcRolesHtml += '<li><input name="roleIds" type="checkbox" '+(n.isCheck?"checked":"")+' class="cheking" value="'+n.roleId+'"/>'+n.roleName+'</li>';
								}else if(n.sysType==2){//微信端角色
									wxRolesHtml += '<li><input name="roleIds" type="checkbox" '+(n.isCheck?"checked":"")+' class="cheking" value="'+n.roleId+'"/>'+n.roleName+'</li>';
								}
							});
							pcRolesHtml+='</ul>';
							wxRolesHtml+='</ul>';
							$('#roleDiv').html(pcRolesHtml+wxRolesHtml);
						}else{
							zdalert('提示',result.msg);
						}
					}
				});
			}else{
				var url = this.config.getRolesUrl;
				$.ajax({
					url:url,
					type:'POST',
					success:function(result){
						if(result.code=='SUCCESS'){
							var pcRolesHtml = '<h6>PC端角色</h6><ul>';
							var wxRolesHtml = '<h6>微信端角色</h6><ul>';
							
									$.each(result.data,function(i,n){
								if(n.sysType==1){//pc端角色
									pcRolesHtml += '<li><input name="roleIds" type="checkbox" class="cheking" value="'+n.roleId+'"/>'+n.roleName+'</li>';
								}else if(n.sysType==2){//微信端角色
									wxRolesHtml += '<li><input name="roleIds" type="checkbox" class="cheking" value="'+n.roleId+'"/>'+n.roleName+'</li>';
								}
							});
							pcRolesHtml+='</ul>';
							wxRolesHtml+='</ul>';
							$('#roleDiv').html(pcRolesHtml+wxRolesHtml);
						}else{
							zdalert('提示',result.msg);
						}
					}
				});
			}
		},
		
		//提交保存
		save:function(){
			//校验参数
			var pwdReg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/;//6到16位数字与字母组合
//          var mobilereg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
            var mobilereg = /^1[0-9]{10}$/;           
            var sfz = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/
			var password = $('input[name=password]').val();
			var userId = getUrlParam('id');
//			if ($('input[name=idNumber]').val() != '') {
//              if (!sfz.test($.trim($('input[name=idNumber]').val()))) {
//                  zdalert('提示', '请输入正确的身份证号码');
//                  return false;
//              }
//          } else {
//              zdalert('提示', '请输入身份证号码');
//              return false;
//          }
			if(userId){
				if($('input[name=password]').val() != ''){
				if(!pwdReg.test(password)){
                    zdalert('提示', '密码请输入6到16位的数字与字母组合');
				return false;
				}
				}
			}else{
				if(!pwdReg.test(password)){
                    zdalert('提示', '密码请输入6到16位的数字与字母组合');
				return false;
				}
			}

            // if ($('input[name=mobile]').val() != '') {
            //     if (!mobilereg.test($.trim($('input[name=mobile]').val()))) {
            //         zdalert('提示', '请输入正确的手机号码');
            //         return false;
            //     }
            // } else {
            //     zdalert('提示', '请输入手机号码');
            //     return false;
            // }

			$("#form").submit();
		}
		
	};
	
	$(function() {
		window.userEdit = new UserEdit();
		$('#getTypelist').change(function(){
			if($("select[name='type']").val()=='1'){
				$('#userhide').show();
			}else if($("select[name='type']").val()=='2'){
				$('#userhide').hide();
			}else if($("select[name='type']").val()=='0'){
				$('#userhide').hide();
			}
		});
	});
})();



$.ajax({
	url: '/tuitionSystem/role/getRole',
	type: 'POST',
	success: function (result) {
		if (result.code == "SUCCESS") {
			var role = "";
			var data = result.data;
			for (var i = 0; i < data.length; i++) {
				if (data[i].id == 4 || data[i].id == 1) {
					continue;
				}
				role += "<option value=" + data[i].id + ">" + data[i].name + "</option>";
			}
		}
		$("#getTypelist").html(role);
	}
});
