/**
 * 用户管理 用户列表js
 */
(function() {
	
	var UserList = function() {
		this.init();
	};
	
	UserList.prototype = {
		
		//配置信息
		config : {
			loadUserListPageUrl:serverBaseUrl + 'manager/system/sysUser/user/page',
			updateStatusUrl:serverBaseUrl + 'manager/system/sysUser/user/status'
		},
		
		//初始化方法
		init:function(){
			if(parent.hasMenuCode('m_011_001_002')){
				$('#add').show();
			}
			this.loadUserListPage();
		},
		
		//加载分页数据
		loadUserListPage:function(){
			Grid.options.params = this.getParams();//请求参数
			Grid.options.url=this.config.loadUserListPageUrl;//请求url
			Grid.options.type='POST';
			//Grid.options.showNumber=true;//是否显示序号  default false;
			//Grid.options.usePage=false;//是否分页 default :true;
			//Grid.options.usePageId = '';//分页控件htmlId  , default:paged
			//Grid.options.pageSize=20;//分页条数 ；default:10
			//Grid.options.pageNum=1;//当前页数 ；default:1
			//Grid.options.checkBox=false;//是否带checkBox default :false;
			Grid.options.columns = [
				{title:'用户ID',value:'userId'},
				{title:'登录名',value:'userName'},
				{title:'姓名',value:'realName'},
//				{title:'手机号',value:'mobile'},
				{title:'状态',func:function(n){
					if(n.status){
						return '启用';
					}else{
						return '停用';
					}
				}},
				{title:'用户类型',func:function(n){
					if(n.type == '1'){
                        if (n.agentsType == '1') {
                            return '渠道';
                        } else {
                            return '代理';
                        }
					}else if(n.type == '2'){
						return '运营人员';
					}else if(n.type == '0'){
						return '管理员';
					}else if(n.type == '3'){
                        return 'CP';
                    }
				}},
				{title:'创建时间',func:function(n){
					return new Date(n.createTime).Format('yyyy-MM-dd hh:mm:ss'); 
				}},
				{title:'最后登录时间',func:function(n){
					return new Date(n.lastLoginTime).Format('yyyy-MM-dd hh:mm:ss'); 
				}},
				{title:'操作',func:function(n){
					var html = '';
					if(parent.hasMenuCode('m_011_001_001')){
						html += '<a href="user-edit.html?id='+n.userId+'">编辑</a>&nbsp;<i>|</i>';
					}
					if(parent.hasMenuCode('m_011_001_003')){
						if(n.status==1){
							html += "<a href=\"javascript:window.userList.updateStatus("+n.userId+","+0+")\">停用</a>&nbsp;";
						}else{
							html += "<a href=\"javascript:window.userList.updateStatus("+n.userId+","+1+")\">启用</a>&nbsp;";
						}
					}
					return html;
				}}
				
			];
			Grid.load("grid");
		},
		search:function(){
			Grid.options.pageNum=1;
			this.loadUserListPage();
		},
		
		//获取查询条件参数｛｝
		getParams:function(){
			var params = {};
			var realName = $.trim($('#realName').val());
//			var mobile = $.trim($('#mobile').val());
			var status = $.trim($('#status').val());
			var roleId = $.trim($('#roleId').val());
			if(realName){
				params['realName']=realName;
			}
//			if(mobile){
//				params['mobile']=mobile;
//			}
			if(status){
				params['status']=status;
			}
			if(roleId){
				params['roleId']=roleId;
			}
			return params;
		},
		
		//启用、禁用 用户
		updateStatus:function(userId,status){
			var that = this;
			zdconfirm('系统确认','确定要'+(status?'启用':'停用')+'该用户吗？',function(flag){
				if(flag){
					var url = that.config.updateStatusUrl;
					$.ajax({
						url:url,
						type:'POST',
						data:{sysUserId:userId,status:status},
						success:function(result){
							if(result.code=='SUCCESS'){
								zdalert('提示','操作成功',function(){
									window.userList.loadUserListPage();
								});
							}else{
								zdalert('提示',result.msg);
							}
						}
					});
				}
			});
		}
		
	};
	
	$(function() {
		window.userList = new UserList();
		$('#search').click(function(){
			window.userList.search();
		});
		$('#add').click(function(){
			window.location.href='user-edit.html';
		});
	});
})();

