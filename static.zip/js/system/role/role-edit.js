/**
 * 角色管理 角色添加、编辑js
 */
(function () {

	var RoleEdit = function () {
		this.init();
	};

	RoleEdit.prototype = {

		//配置信息
		config: {
			// getRoleInfoByRoleIdUrl:serverBaseUrl + 'manager/system/sysUser/role/get',
			// editRoleUrl:serverBaseUrl + 'manager/system/sysUser/role/edit',
			// addRoleUrl:serverBaseUrl + 'manager/system/sysUser/role/add',
			// getMenusUrl:serverBaseUrl + 'manager/system/sysUser/role/menu'
			getRoleInfoByRoleIdUrl: '/tuitionSystem/role/get',
			editRoleUrl: '/tuitionSystem/role/edit',
			addRoleUrl: '/tuitionSystem/role/add',
			getMenusUrl: '/tuitionSystem/menu/all',
		},

		//初始化方法
		init: function () {
			this.loadRoleInfo();
			this.initAjaxForm();
		},

		//初始化ajaxForm
		initAjaxForm: function () {
			var url = this.config.addRoleUrl;
			var userId = getUrlParam('id');
			var pageTitle = '添加角色';
			if (userId) {
				pageTitle = '编辑角色';
				url = this.config.editRoleUrl;
			}
			$('#pageTitle').html(pageTitle);
			var options = {
				url: url,
				type: 'POST',
				success: function (data) {
					if (data.code == 'SUCCESS') {
						zdalert('提示', '操作成功', function () {
							window.history.go(-1);
						});
					} else {
						zdalert('提示', data.msg);
					}
				}
			};
			$("#form").ajaxForm(options);
		},

		//加载用户数据
		loadRoleInfo: function () {
			var that = this;
			var roleId = getUrlParam('id');
			// var sysType = getUrlParam('sysType');
			if (roleId) {
				var url = this.config.getRoleInfoByRoleIdUrl;
				$.ajax({
					url: url,
					type: 'POST',
					data: { roleId: roleId },
					// data:{roleId:roleId,sysType:sysType},
					success: function (result) {
						if (result.code == 'SUCCESS') {
							var data = result.data;
							$("input[name='roleId']").val(data.id);
							$("input[name='roleName']").val(data.name);
							// $("input[name='desc']").val(data.desc);
							// $("select[name='sysType']").val(data.sysType);
							// $("select[name='sysType']").attr('disabled',true);
							// $("select[name='defaultRole']").val(data.defaultRole);
							// $("select[name='status']").val(data.status);
							var menuHtml = that.getMenuTree(data.menuList);
							$('#well').html(menuHtml);
						} else {
							zdalert('提示', result.msg);
						}
					}
				});
			} else {
				var url = this.config.getMenusUrl;
				$.ajax({
					url: url,
					data: { sysType: 1 },
					type: 'POST',
					success: function (result) {
						if (result.code == 'SUCCESS') {
							var menuHtml = that.getMenuTree(result.data);
							$('#well').html(menuHtml);
						} else {
							zdalert('提示', result.msg);
						}
					}
				});
			}
		},

		//切换系统 、切换菜单
		changeMenu: function (o) {
			var that = this;
			var url = that.config.getMenusUrl;
			$.ajax({
				url: url,
				data: { sysType: o.value },
				type: 'POST',
				success: function (result) {
					if (result.code == 'SUCCESS') {
						var menuHtml = that.getMenuTree(result.data);
						$('#well').html(menuHtml);
					} else {
						zdalert('提示', result.msg);
					}
				}
			});

		},

		//构建菜单树html
		getMenuTree: function (menus) {
			var that = this;
			var html = '<ul>';
			$.each(menus, function (i, n) {
				// var class_ = 'icon-folder-open';
				// if(n.type==2){
				// 	class_ = 'icon-minus-sign';
				// }else if(n.type==3){
				// 	class_ = 'icon-leaf';
				// }
				// html +='<li><input type="checkbox" name="menuIdList" '+(n.isCheck?"checked":"")+' value="'+n.menuId+'"/><span><i class="'+class_+'"></i>'+n.menuName+'</span> <a href=""></a>';
				// if(n.childList){
				// 	html += that.getMenuTree(n.childList);
				// }
				var class_ = 'icon-folder-open';
				if (n.parentId != 0) {
					class_ = 'icon-minus-sign';
				}
				if (n.menuType == false) {
					class_ = 'icon-leaf';
				}
				html += '<li><input type="checkbox" name="menuIdList" ' + (n.isCheck ? "checked" : "") + ' value="' + n.id + '"/><span><i class="' + class_ + '"></i>' + n.name + '</span> <a href=""></a>';
				if (n.childrenMenu) {
					html += that.getMenuTree(n.childrenMenu);
				}
				if (n.buttonList) {
					html += that.getMenuTree(n.buttonList);
				}
			});
			html += '</ul>';
			return html;
		},

		transformJSON: function () {
			var data = $("#form").serializeArray();
			var jsonData = {};
			$.each(data, function () {
				if (jsonData[this.name]) {
					if (!jsonData[this.name].push) {
						jsonData[this.name] = [jsonData[this.name]];
					}
					jsonData[this.name].push(this.value || '');
				} else {
					jsonData[this.name] = this.value || '';
				}
			});
			alert(JSON.stringify(jsonData))
			return jsonData;
		},
		//提交保存
		save: function () {
			//校验参数
			if ($("input[name='roleName']").val() == '') {
				zdalert('提示', '角色名称不能为空！');
			} else if (!$("input[name='menuIdList']").is(":checked")) {
				zdalert('提示', '没有选择菜单功能！');
			} else {
				$("#form").submit();
			}
		}

	};
	$(function () {
		window.roleEdit = new RoleEdit();
	});
})();

