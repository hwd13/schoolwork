/**
 * 角色管理 角色列表js
 */
(function() {
	var RoleList = function() {
		this.init();
	};
	RoleList.prototype = {
		//配置信息
		config : {
			// loadRoleListPageUrl:serverBaseUrl + 'manager/system/sysUser/role/list',
			loadRoleListPageUrl:'/tuitionSystem/role/list',
			// deleteUrl:serverBaseUrl + 'manager/system/sysUser/role/delete'
		},
		
		//初始化方法
		init:function(){
			// if(parent.hasMenuCode('m_011_002_002')){
			// 	$('#add').show();
			// }
			this.loadRoleListPage();
		},
		
		//加载列表数据
		loadRoleListPage:function(){
			Grid.options.params = this.getParams();//请求参数
			Grid.options.url=this.config.loadRoleListPageUrl;//请求url
			Grid.options.type='POST';
			Grid.options.usePage=false;//是否分页 default :true;
			Grid.options.dataAttribute='data';//指定数据属性值 ， default: data.list
			//Grid.options.usePageId = '';//分页控件htmlId  , default:paged
			//Grid.options.pageSize=20;//分页条数 ；default:10
			//Grid.options.pageNum=1;//当前页数 ；default:1
			//Grid.options.checkBox=false;//是否带checkBox default :true;
			Grid.options.columns = [
				{title:'角色ID',value:'id'},
				{title:'角色名称',value:'name'},
				// {title:'角色ID',value:'roleId'},
				// {title:'角色名称',value:'roleName'},
				// {title:'所属系统',func:function(n){
				// 	if(n.sysType==1){
				// 		return '运营系统PC端';
				// 	}else{
				// 		return '运营系统微信端';
				// 	}
				// }},
				// {title:'默认授权用户',func:function(n){
				// 	if(n.roleId==1){
				// 		return '系统管理员';
				// 	}else if(n.roleId==2){
				// 		return '财务管理员';
				// 	}else if(n.roleId==3){
                //         return '辅导员';
                //     }else if(n.roleId==4){
				// 		return '学生';
				// 	}
				// }},
				// {title:'状态',func:function(n){
				// 	if(n.status==1){
				// 		return '启用';
				// 	}else if(n.status==0){
				// 		return '停用';
				// 	}else{
				// 		return '';
				// 	}
				// }},
				{title:'创建时间',func:function(n){
					return new Date(n.createTime).Format('yyyy-MM-dd hh:mm:ss'); 
				}},
				{title:'操作',func:function(n){
					var html = '';
					// if(parent.hasMenuCode('m_011_002_001')){
					// 	html += '<a href="role-edit.html?id='+n.roleId+'">编辑</a>&nbsp;';
					// }
						html += '<a href="role-edit.html?id='+n.id+'">编辑</a>&nbsp;';
					return html;
				}}
				
			];
			Grid.load("grid");
		},
		
		//获取查询条件参数｛｝
		getParams:function(){
			var params = {} ;
			var sysType = $('#sysType').val();
			if(sysType){
				params['sysType'] = sysType;
			}
			return params;
		},
		
		//搜索
		search:function(){
			Grid.options.pageNum=1;
			this.loadRoleListPage();
		}
		
		//删除 角色
//		delete:function(roleId){
//			var that = this;
//			zdconfirm('系统确认','确定要删除该角色吗？',function(flag){
//				if(flag){
//					var url = that.config.deleteUrl;
//					$.ajax({
//						url:url,
//						type:'POST',
//						data:{roleId:roleId},
//						success:function(result){
//							if(result.code=='SUCCESS'){
//								zdalert('提示','操作成功',function(){
//									window.roleList.loadRoleListPage();
//								});
//							}else{
//								zdalert('提示',result.msg);
//							}
//						}
//					});
//				}
//			});
//		}
	};
	
	$(function() {
		window.roleList = new RoleList();
		$('#search').click(function(){
			window.roleList.search();
		});
		$('#add').click(function(){
			window.location.href='role-edit.html';
		});
	});
})();
