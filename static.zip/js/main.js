/** index.js By Beginner Emain:zheng_jinfan@126.com HomePage:http://www.zhengjinfan.cn */
var menusCodeCache = {};
var userType = 0;
var tab;

//构建菜单树
function buildMenuTree(menuList) {
	var menus = [];
	for (var i = 0; i < menuList.length; i++) {
		menusCodeCache[menuList[i].menuCode] = menuList[i].isCheck;
		if (menuList[i].type != 3 && menuList[i].isCheck) {
			var menu = { 'title': menuList[i].menuName, 'spread': true, 'icon': 'fa-table' };
			if (menuList[i].childList) {
				var childs = buildMenuTree(menuList[i].childList);
				if (childs.length != 0) {
					menu['children'] = childs;
				}
			}
			if (menuList[i].url) {
				menu['href'] = menuList[i].url.split('\,')[0];
			}
			if (menuList[i].img) {
				//menu['icon']=menuList[i].img;
			}
			menus.push(menu);
		}
	}
	return menus;
}

function hasMenuCode(code) {
	return menusCodeCache[code];
}
function openPassWord() {
	var field = { href: 'index-password.html', icon: 'fa-table', title: '修改密码' };
	parent.tab.tabAdd(field);
}
layui.config({
	base: '../js/',
	version: new Date().getTime()
}).use(['element', 'layer', 'navbar', 'tab'], function () {
	var element = layui.element(),
		$ = layui.jquery,
		layer = layui.layer,
		navbar = layui.navbar();
	tab = layui.tab({
		elem: '.admin-nav-card' //设置选项卡容器
		,
		//maxSetting: {
		//	max: 5,
		//	tipMsg: '只能开5个哇，不能再开了。真的。'
		//},
		contextMenu: true,
		onSwitch: function (data) {
			var oldvalue = $('iframe[data-id=' + data.index + ']').height()
			setTimeout(function () {
				$('iframe[data-id=' + data.index + ']').height(oldvalue + 1)
			}, 500)
		},
	});
	//iframe自适应
	$(window).on('resize', function () {
		var $content = $('.admin-nav-card .layui-tab-content');
		$content.height($(this).height() - 147);
		$content.find('iframe').each(function () {
			$(this).height($content.height());
		});
	}).resize();
	$.ajax({
		url: serverBaseUrl + 'manager/login/getSessionUser',
		success: function (result) {
			if (result.code == 'SUCCESS') {
				//首页
				if (result.data.type == 1 || result.data.type == 3) {
					$('#index_iframe').attr('src', 'index-agent.html');
					if (result.data.omsAgentsVo) {
						agentType = result.data.omsAgentsVo.type;
					}
					userType = 1;
				}
				else {
					$('#index_iframe').attr('src', 'index.html');
				}
				//设置navbar
				var navs = buildMenuTree(result.data.systemMenuVOList);
				navbar.set({
					spreadOne: true,
					elem: '#admin-navbar-side',
					cached: true,
					data: navs
					/*cached:true,
					url: 'datas/nav.json'*/
				});
				//渲染navbar
				navbar.render();
				//监听点击事件
				navbar.on('click(side)', function (data) {
					if (data.field.title == '首页') {
						$('#indexLi').click();
					}

					tab.tabAdd(data.field);
				});
			} else {
				zdalert('提示', result.msg);
			}
		}
	});

	//手机设备的简单适配
	var treeMobile = $('.site-tree-mobile'),
		shadeMobile = $('.site-mobile-shade');
	treeMobile.on('click', function () {
		$('body').addClass('site-mobile');
	});
	shadeMobile.on('click', function () {
		$('body').removeClass('site-mobile');
	});
	$.ajax({
		url: serverBaseUrl + 'manager/login/getSessionUser',
		type: 'GET',
		success: function (result) {
			if (result.code == 'SUCCESS') {
				var data = result.data;
				$('#userName').html(data.realName + (data.agentsId ? '(' + data.agentsId + ')' : ''));
			} else {
				zdalert('提示', result.msg);
			}
		}
	});

	$(".loginOut").click(function () {
		$.ajax({
			url: serverBaseUrl + 'manager/login/out',
			type: 'POST',
			success: function (result) {
				if (result.code == 'SUCCESS') {
					sessionStorage.clear()
					window.location.href = 'login.html';
				} else {
					zdalert('提示', result.msg);
				}
			}
		});
	});
});
